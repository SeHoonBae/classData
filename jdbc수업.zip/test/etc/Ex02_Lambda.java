package com.test.etc;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class Ex02_Lambda {

	public static void main(String[] args) {
		
		//람다식 : 메소드를 간략하게 작성
		
		//정렬
		List<User> list = new ArrayList<User>();
		
		list.add(new User("홍길동",25));
		list.add(new User("아무개",27));
		list.add(new User("테스트",23));
		list.add(new User("하하하",20));
		list.add(new User("호호호",21));
		
		System.out.println(list);
		
		//컬렉션 정렬
		//1. Collections.sort(list)
		//2. list.sort()
//		Collections.sort(list); // 단일 타입 정렬 O, 복합 타입 정렬 X
		list.sort(new Comparator<User>() {

			@Override
			public int compare(User o1, User o2) {

				return o1.getAge() - o2.getAge(); // 나이 오름차순 정렬
//				return o2.getAge() - o1.getAge(); // 나이 내림차순 정렬
//				return o1.getName().compareTo(o2.getName()); // 이름 오름차순 정렬
//				return o2.getName().compareTo(o1.getName()); // 이름 내림차순 정렬
			}
			
		});
		
		System.out.println(list);
		
		
		list.sort( (o1, o2) ->  o1.getAge() - o2.getAge()  );
		list.sort( (o1, o2) ->  o1.getName().compareTo(o2.getName()) );
		
		System.out.println(list);
		
		
		TreeSet<User> set = new TreeSet<User>( (o1, o2) -> o1.getAge() - o2.getAge() ); // 나이 오름차순 정렬
		
		set.add(new User("홍길동",25));
		set.add(new User("아무개",27));
		set.add(new User("테스트",23));
		set.add(new User("하하하",20));
		set.add(new User("호호호",21));
		
		System.out.println(set);
		
		
	}
	
}


class User{
	
	private String name;
	private int age;
	
	public User(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "name=" + name + ", age=" + age + "\r\n";
	}
	
	
	
}




