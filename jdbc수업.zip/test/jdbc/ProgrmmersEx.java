package com.test.jdbc;

public class ProgrmmersEx {

	public static void main(String[] args) {
		
		String a = "AB";
		String b = "a";
		String c = "a B z";
		
//		System.out.println(solution(a,1));
//		System.out.println(solution(b,1));
//		System.out.println(solution(c,4));
		
		System.out.println((int)'a');
		
	}
	
	// A,B -> 1만큼 밀면 B,C, Z -> A
	public String solution(String s, int n) {
		
		String answer = "";
		
		char[] charS = s.toCharArray();
		
		for(int i = 0; i < charS.length; i++) {
			
			if(charS[i] == ' ' ) continue;
			else if(charS[i] >= 'a' && charS[i] <= 'z') {
				
				int low = (int)charS[i] + n;
				
				if( low > 90 ){
					low = low - (n % 65);
				}
			}
		}
		
		
		return answer;
	}
	
	
}
