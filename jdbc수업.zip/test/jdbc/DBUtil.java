package com.test.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	public Connection connect() {
		
		Connection conn = null;
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String id = "hr";
		String password = "java1234";
		
		try {
			
			//3. jar 설치 > 설치한 JDBC 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//4. 접속
			// - Connection 객체 생성 > DB 연결 정보를 가지고 있는 상태
			// - DB 접속
			conn = DriverManager.getConnection(url,id,password);
			
			return conn;
			
		} catch(Exception e) {
			System.out.println("Connection : " + e.toString());
		}
		
		return null;
		
	}
	
	
	public Connection connect(String server, String id, String password) {
		
		Connection conn = null;
		
		String url = "jdbc:oracle:thin:@"+server+":1521:xe";
		
		try {
			
			//3. jar 설치 > 설치한 JDBC 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//4. 접속
			// - Connection 객체 생성 > DB 연결 정보를 가지고 있는 상태
			// - DB 접속
			conn = DriverManager.getConnection(url,id,password);
			
			return conn;
			
		} catch(Exception e) {
			System.out.println("Connection : " + e.toString());
		}
		
		return null;
		
	}



	
}
