package com.test.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import oracle.jdbc.internal.OracleTypes;

public class Ex08_CallableStatement {
	
	private static Connection conn;
	private static CallableStatement cstat;
	
	static {
		DBUtil util = new DBUtil();
		conn = util.connect();
	}

	public static void main(String[] args) {
		
		//1. Statement : 정적 쿼리
		//2. PreparedStatement : 동적 쿼리(매개 변수)
		//3. CallableStatement : 프로시저 호출 전용
		
//		m1();
//		m2();
//		m3();
//		m4();
//		m5();
		
	}

	private static void m5() {
		
		// procListTodo
		
		try {
			
			String sql = "{ call procListTodo(?) }"; // 매개변수가 없어도 () 써야됨
			cstat = conn.prepareCall(sql);
			
			cstat.registerOutParameter(1, OracleTypes.CURSOR);
			
			cstat.executeQuery(); // out 파라미터는 ResultSet 안씀!
			
//			cstat.getObject(1); // select 의 결과인 cursor가 자바의 ResultSet으로 반환
			ResultSet rs = (ResultSet) cstat.getObject(1);
			
			while(rs.next()) {
				System.out.println(rs.getString("title"));
			}
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}

	private static void m4() {

		//procCountSetTodo(out 안한일, out 한일, out 모두)
		
		try {
			
			String sql = "{ call procCountSetTodo(?,?,?) }";
			
			cstat = conn.prepareCall(sql);
			
			cstat.registerOutParameter(1, OracleTypes.NUMBER);
			cstat.registerOutParameter(2, OracleTypes.NUMBER);
			cstat.registerOutParameter(3, OracleTypes.NUMBER);
			
			cstat.executeQuery(); // 선택 무관
			
			int cnt1 = cstat.getInt(1);
			int cnt2 = cstat.getInt(2);
			int cnt3 = cstat.getInt(3);
			
			System.out.println(cnt1);
			System.out.println(cnt2);
			System.out.println(cnt3);
			
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		
		
	}

	private static void m3() {
		
		//procDeleteTodo(in 삭제할 번호, out 결과)
		
		try {
			
			String sql = "{ call procDeleteTodo(?,?) }";
			cstat = conn.prepareCall(sql);
			
			cstat.setString(1, "56"); // in
			cstat.registerOutParameter(2, OracleTypes.NUMBER); // out
			
			cstat.executeUpdate();
			
			System.out.println(cstat.getInt(2));
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}

	private static void m2() {
		
		//procCompleteTodo(in 수정할 번호, out 결과)
		
		try {
			
			String sql = "{ call procCompleteTodo(?,?) }";
			
			cstat = conn.prepareCall(sql);
			
			cstat.setString(1, "56"); // in
			cstat.registerOutParameter(2, OracleTypes.NUMBER); // out
			
			cstat.executeUpdate();
			
			int result = cstat.getInt(2);
			
			System.out.println(result);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}

	private static void m1() {
		
		//procAddTodo
		// - in : ptitle(varchar2)
		// - out : presult(num)
		
		try {
			
			String sql = "{ call procAddTodo(?,?) }";
			
			cstat = conn.prepareCall(sql);
			
			// in 매개변수
			cstat.setString(1, "할일 제목");
			
			// out 매개변수
			cstat.registerOutParameter(2, OracleTypes.NUMBER);
			
			cstat.executeQuery();
			
			// 받아오기로 한 값 > out 매개변수 (<> ResultSet)
			int result = cstat.getInt(2); // cstat.registerOutParameter(2, OracleTypes.NUMBER); 2번과 동일
			
			System.out.println(result);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}
	
}
