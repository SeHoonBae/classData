package com.test.memo2;

interface IService {

	void add();

	void list();

	void edit();

	void del();

	void search();


	
	
}
