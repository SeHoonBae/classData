-- ex12_function

/*

문자열 함수
1. upper(), lower()
- varchar2 upper(컬럼명)

*/

SELECT
    'studentName',
    upper('studentName'),
    lower('studentName'),
    initcap('studentName')
FROM dual;

-- employee > 'AN' 포함 직원
SELECT first_name FROM employees WHERE upper(first_name) like '%AN%';

-- 'AN' > 사용자가 입력한 값 > 변수
SELECT first_name FROM employees WHERE upper(first_name) like '%' || upper('AN') || '%';

/*
2. substr
- 문자열 추출 함수
- varchar2 substr(컬럼명, 시작위치, 개수)
- varchar2 substr(컬럼명, 시작위치)
-- 서수(인덱스)가 1부터 시작한다.(***)
*/

SELECT '가나다라마바사아자차카타파하' FROM dual;
SELECT substr('가나다라마바사아자차카타파하', 5, 3) FROM dual;
SELECT substr('가나다라마바사아자차카타파하',5) FROM dual;
SELECT substr('가나다라마바사아자차카타파하',-5,3) FROM dual;

SELECT name, substr(name, 1, 1) as 성, substr(name, 2) as 이름 FROM tblinsa;

-- 남자 직원수?
SELECT count(case when substr(ssn, 8, 1) = '1' then 1 end) FROM tblinsa;
SELECT count(*) FROM tblinsa WHERE ssn like '%-1%';
SELECT count(*) FROM tblinsa WHERE substr(ssn, 8, 1) = '1';

-- 남자(1, 3, 5, 7, 9)
SELECT count(*) FROM tblinsa WHERE substr(ssn, 8, 1) in ('1', '3', '5', '7', '9'); --*****
SELECT count(*) FROM tblinsa WHERE mod(substr(ssn, 8, 1),2) = '1';

/*
1. 직원명과 생년을 가져오시오. (ssn > 1999년대 생)
[이름]    [생년]
홍길동     1990
아무개     1994
...

2. 서울에 사는 여직원 중 80년대생 총 몇명?

3. 장급(부장, 과장)들은 어떤 성씨

4. 직원들을 태어난 월순으로 정렬을 해서 가져오시오.(오름차순 -> 월, 이름)
*/

--1.
SELECT name as 이름, 19 || substr(ssn,1,2) as 생년 FROM tblinsa WHERE substr(ssn,1,1) = '9';
--2.
SELECT count(*) FROM tblinsa WHERE substr(ssn,8,1) = '2' and city = '서울' and substr(ssn,1,1) = '8';
--3.
SELECT substr(name,1,1) FROM tblinsa WHERE jikwi in ('부장', '과장');
--4.
SELECT name as 이름, substr(ssn,3,4) as 월 FROM tblinsa order by substr(ssn,3,4);

-- 여기부터 오후수업

/*
3. length()
- 문자열 길이
- number length(컬럼명)

*/

SELECT name, length(name) FROM tblcountry;

-- 조건절
SELECT name FROM tblcountry WHERE length(name) > 3;
SELECT name FROM tblcountry WHERE length(name) between 3 and 5;
SELECT name FROM tblcountry WHERE length(name) in (3,7);

-- 정렬
SELECT name FROM tblcountry order by length(name) desc;

SELECT
    case
        when length(name) >= 4 then substr(name,1,3) || '..'
        else name
    end
FROM tblcountry;

/*
1. 이름(first_name + last_name)이 가장 긴 순서대로 가져오시오.
2. 이름(first_name + last_name)이 가장 긴 사람은 몇글자?
3. last_name이 4자인 사람들의 first_name이 궁금하다.
*/

--1.
SELECT * FROM employees order by length(first_name||last_name) desc;
--2.
SELECT  max(length(first_name||last_name)) FROM employees;
--3.
SELECT first_name FROM employees WHERE length(last_name) = 4;

/*
4. instr
- indexOf
- 검색어의 위치 반환
- number instr(컬럼명, 검색어)
- number instr(컬럼명, 검색어, 시작위치)
- number instr(컬럼명, 검색어, 시작위치, 검색어 몇번째)
*/

SELECT '안녕하세요. 홍길동님.' FROM dual;
SELECT instr('안녕하세요. 홍길동님.','홍길동') FROM dual;

SELECT instr('안녕하세요. 홍길동님.안녕하세요. 홍길동님.','홍길동',1,2) FROM dual;

-- 이름에 '길'자가 포함된 직원?
SELECT * FROM tblinsa WHERE instr(name, '길') > 0;
SELECT * FROM tblinsa WHERE name like '%길%';

SELECT * FROM tblinsa WHERE instr(name,'길') > 0 order by instr(name, '길');


/*
5. lpad, rpad
- varchar2 lpad(컬럼명, 바이트, 문자)
- varchar2 rpad(컬럼명, 바이트, 문자)
- 한글은 2바이트 나머지 1바이트로 취급

*/

SELECT title, lpad(title,30,'@') FROM tbltodo;
SELECT lpad(seq,2,'0') FROM tbltodo; -- String.format("%03d",seq)

SELECT
    lpad(1,3,'0'),
    lpad(12,3,'0'),
    lpad(123,3,'0'),
    lpad(1234,3,'0'),
    lpad('abcd',3,'0')
from dual;

CREATE TABLE tblChar
(
    txt1 char(10), -- 고정자릿수
    txt2 varchar2(10) -- 가변자릿수
);

INSERT INTO tblChar (txt1, txt2) values ('abc', 'abc');

SELECT * FROM tblChar;
SELECT length(txt1), length(txt2) FROM tblChar;

SELECT * FROM tblChar WHERE txt2 = 'abc';
SELECT * FROM tblChar WHERE txt1 = 'abc'; -- 잘못된 상황(오라클 편의를 봐줘서 결과가 나옴)
SELECT * FROM tblChar WHERE length(trim(txt1)) = 3; -- txt1이 char(10)으로 길이는 10임
-- varchar2만 사용

/*
6. trim(), ltrim(), rtrim()
- varchar2 trim(컬럼명)
*/

SELECT '     홍길동   ' FROM dual;
SELECT trim('     홍길동   ') FROM dual;
SELECT ltrim('     홍길동   ') FROM dual;
SELECT rtrim('     홍길동   ') FROM dual;

/*
7. replace
- 문자열 치환
- varchar2 replace(컬럼명, 찾을 문자열, 바꿀 문자열)
*/

SELECT replace('홍길동', '홍', '김') FROM dual;

SELECT name, replace(replace(substr(ssn, 8, 1),'1','남자'),'2','여자') FROM tblinsa;

SELECT
    name,
    case
        when continent = 'AS' then '아시아'
        when continent = 'EU' then '유럽'
        when continent = 'AF' then '아프리카'
        when continent = 'AU' then '오스트레일리아'
        when continent = 'SA' then '아메리카'
    end
FROM tblcountry;

SELECT name, replace(replace(replace(replace(replace(continent, 'AS', '아시아'),'EU','유럽'),'AF','아프리카'),'SA','아메리카'),'AU','오스트레일리아')
FROM tblCountry;

/*
8. decode()
- 문자열 치환
- replace() 유사, case end 유사
- varchar2 decode(컬럼명, 문자열, 문자열, 문자열, 문자열,...)
*/
SELECT
    replace(replace(continent, 'AS', '아시아'),'EU', '유럽'),
    decode(continent,'AS','아시아', 'EU', '유럽', 'AF', '아프리카', 'SA', '아메리카','AU','오스트레일리아')
FROM tblCountry;

SELECT
    count(case
        when jikwi = '부장' or jikwi = '과장' then 1
    end),
    count(case
        when jikwi in ('사원', '대리') then 1
    end)
    
FROM tblinsa;

SELECT 
    count(decode(jikwi, '부장', '1', '과장', '1')),
    count(decode(jikwi, '사원', '1', '대리', '1'))
FROM tblinsa;

/*
1.아래와 같이 가져오시오.
[아시아]   [유럽]    [아프리카]  [오스트레일리아]   [아메리카]
4           3       1           1               2
2. 아래와 같이 가져오시오.
[김]     [이]     [박]     [최]     [정]
5       12         3        7       3
*/
--1.
SELECT 
    count(decode(continent,'AS','1')) "[아시아]",
    count(decode(continent,'EU','1')) "[유럽]",
    count(decode(continent,'AF','1')) "[아프리카]",
    count(decode(continent,'AU','1')) "[오스트레일리아]",
    count(decode(continent,'SA','1')) "[아메리카]"
FROM tblCountry;

--2.
SELECT
    count(decode(substr(name,1,1),'김','1')) "[김]",
    count(decode(substr(name,1,1),'이','1')) "[이]",
    count(decode(substr(name,1,1),'박','1')) "[박]",
    count(decode(substr(name,1,1),'최','1')) "[최]",
    count(decode(substr(name,1,1),'정','1')) "[정]"
FROM tblinsa;