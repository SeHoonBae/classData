-- ex13_function

-- 하면 안되는 행동(내일)
SELECT ibsadate, substr(ibsadate,4,2) FROM tblinsa;

/*

날짜/시간 함수
1. sysdate
- 현재 시간 반환
- date sysdate
- 자바의 Calendar.getInstance() 동일

*/
SELECT sysdate FROM dual;

-- 날짜 연산
-- + 날짜, - 날짜
SELECT sysdate + 3 FROM dual;
SELECT sysdate - 3 FROM dual;

SELECT 고객명, 대여일, 대여일 + 대여기간 as 반납예정일 FROM 도서관;

SELECT name, ibsadate, ibsadate + 10000 FROM tblinsa;

-- 날짜 - 날짜 = 일
SELECT name, sysdate - ibsadate as 근무일수 FROM tblinsa;
SELECT name, round((sysdate - ibsadate)/365,1) as 근무년수 FROM tblinsa;
SELECT name, floor((sysdate - ibsadate)/365) as 근무년수 FROM tblinsa;
SELECT name, ceil((sysdate - ibsadate)/365) as 근무년수 FROM tblinsa;

--1번 정리
-- 시각 + 숫자(일) = 시각
-- 시각 - 시각 = 숫자(일)

/*
2. last_day()
- 해당 시각이 포함된 달의 마지막 날짜(시각)
- date last_dat(date)
*/

SELECT last_day(sysdate) FROM dual;

/*
3. months_between()
- number months_between(date,date)
*/
SELECT 
    name,
    round(sysdate - ibsadate) as 근무일수, -- ***
    round((sysdate - ibsadate) / 30) as 근무월수, -- 임시로 30일 지정, 사용금지
    round(months_between(sysdate, ibsadate)) as 근무월수, -- ***
    round((sysdate - ibsadate) / 30/12) as 근무년수, -- 임시로 30일 지정, 사용금지
    round(months_between(sysdate, ibsadate)/12) as 근무월수 -- ***
FROM tblinsa;
SELECT months_between(sys) FROM dual;

/*
4. add_months()
- date add_months(date, number)
*/
SELECT sysdate + 1 FROM dual; -- 하루뒤
SELECT sysdate + 30 FROM dual; -- 한달뒤(근사치), 임의로 30일 지정 > 사용금지
SELECT add_months(sysdate, 1) FROM dual; -- 한달뒤(정확한 값)
SELECT add_months(sysdate, -1) FROM dual; -- 한달전(정확한 값)

/*
시각, 시간 연산
1. date + number = date
    : 시각 + 일 = 시각
2. date - date = number
    : 시각 - 시각 = 일
3. add_months(date, number) = date
    : 시각 + 월 = 시각
4. months_between(date, date) = number
    : 시각 - 시각 = 월
*/
