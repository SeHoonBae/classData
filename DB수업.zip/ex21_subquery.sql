-- ex21_subquery

/*

Sub Query, 서브 쿼리
- 쿼리안에 또 다른 쿼리가 있는 형태

SELECT 문 (SELECT 문)
INSERT 문 (SELECT 문)
UPDATE 문 (SELECT 문)
DELETE 문 (SELECT 문)

*/
-- 인구수가 가장 많은 나라의 인구?
SELECT max(population) FROM tblcountry;

-- 인구수가 가장 많은 나라의 국가명?
SELECT max(population) FROM tblcountry;
SELECT name FROM tblcountry WHERE population = max(population);

-- 서브 쿼리의 역할 > 함수의 반환값과 유사
SELECT name FROM tblcountry WHERE population = (SELECT max(population) FROM tblcountry);

-- 직원 중 가장 월급이 많은 사람?
SELECT name FROM tblinsa WHERE basicpay = (SELECT max(basicpay) FROM tblinsa);
-- 월급이 가장 적은 사람
SELECT name FROM tblinsa WHERE basicpay = (SELECT min(basicpay) FROM tblinsa);

SELECT name FROM tblinsa WHERE basicpay < (SELECT avg(basicpay) FROM tblinsa);

-- '김정훈' 직원보다 급여를 더 많이 받는 사람들?
SELECT name FROM tblinsa WHERE basicpay > (SELECT basicpay FROM tblinsa WHERE name = '김정훈');

-- tblmen + tblwomen. 남자 중 키 165cm, 몸무게 58kg > 그남자의 여자친구 정보를 가져오시오.

SELECT * FROM tblwomen WHERE (SELECT couple FROM tblmen WHERE weight = 58 and height = 165) = name;

-- '홍길동'과 같은 부서에 있는 사람
SELECT * FROM tblinsa WHERE buseo = (SELECT buseo FROM tblinsa WHERE name = '홍길동');

-- 서브쿼리의 결과와 단일컬럼(여러개의 값이 나오는)을 비교할 때 반드시 in을 사용한다.(단, 서브쿼리의 결과가 1개 컬럼일때)
-- 급여를 250만 이상 받는 사람과 같은 부서에 있는 사람?
SELECT * FROM tblinsa
    WHERE buseo in (SELECT buseo FROM tblinsa WHERE basicpay >= 2500000);

-- '홍길동'과 같은 부서에 근무하면서 같은 지역에 사는 사람?
SELECT * FROM tblinsa 
    WHERE buseo = (SELECT buseo FROM tblinsa WHERE name = '홍길동')
        and city = (SELECT city FROM tblinsa WHERE name = '홍길동');

-- 1레코드 + 다중 컬럼
SELECT * FROM tblinsa
    WHERE (buseo, city) = (SELECT buseo, city FROM tblinsa WHERE name = '홍길동');

-- 복수 레코드 + 다중 컬럼
SELECT * FROM tblinsa
 WHERE (buseo, city) in (SELECT buseo, city FROM tblinsa WHERE basicpay >= 2600000);

-- 서브 쿼리의 용도
--1. 조건절에 사용
--2. FROM절에 사용 > '인라인 뷰'
--3. 컬럼 리스트에 사용 > 서브 쿼리가 컬럼으로 사용 > 상관 서브쿼리(바깥쪽의 데이터를 안쪽 테이블에서 사용 할 때)

SELECT * FROM tblinsa WHERE buseo = '기획부';

SELECT name, jikwi FROM (SELECT name as 직원명, jikwi, ssn, tel FROM tblinsa WHERE buseo = '기획부'); -- 별칭이 바뀌면 부르는 곳에서도 바뀐 별칭으로 해야 함
SELECT 직원명, jikwi FROM (SELECT name as 직원명, jikwi, ssn, tel FROM tblinsa WHERE buseo = '기획부'); -- 임시 기획부 테이블


SELECT name, jikwi, buseo, (SELECT name FROM tblinsa WHERE num = 1001) FROM tblinsa;

SELECT name, jikwi, buseo, (SELECT count(*) FROM tblinsa) FROM tblinsa;

SELECT name, jikwi, buseo, (SELECT count(*) FROM tblinsa) FROM tblinsa;

SELECT * FROM tblmen;
SELECT * FROM tblwomen;

-- '홍길동'의 키와 여자친구인 '장도연'의 키를 가져오시오.
SELECT height FROM tblmen WHERE name = '홍길동';
SELECT height FROM tblwomen WHERE name = '장도연';

SELECT name, height, (SELECT height FROM tblwomen WHERE name = tblmen.couple) FROM tblmen WHERE name = '홍길동';

SELECT name, height, couple, (SELECT height FROM tblwomen WHERE name = tblmen.couple) FROM tblmen;

SELECT * FROM employees;
SELECT * FROM departments;
SELECT * FROM locations;

-- 'London'(locations)에 위치한 부서(departments)에 근무하는 직원들(employees)?
SELECT * FROM employees WHERE department_id = 40;
SELECT * FROM departments WHERE location_id = 2400;
SELECT * FROM locations WHERE city = 'London';

SELECT * FROM employees 
    WHERE department_id = (SELECT departments.department_id FROM departments 
        WHERE location_id = (SELECT locations.location_id FROM locations WHERE city = 'London'));
