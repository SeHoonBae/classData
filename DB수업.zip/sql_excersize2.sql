-- 1.
SELECT * FROM tblCountry;

-- 2.
SELECT name as 국가명, capital as 수도명 FROM tblCountry;

-- 4.
SELECT * FROM tblCountry;
SELECT '국가명:' || name || ', ' || '수도명' || capital || ', ' || '인구수:' || population as 국가정보 
    FROM tblCountry;

-- 12.
SELECT * FROM tblinsa WHERE buseo = '기획부';

-- 15.
SELECT * FROM tblinsa
    WHERE sudang <= 150000 and jikwi in ('사원','대리');

-- 17.
SELECT * FROM tblCountry WHERE name like '_국';

-- 19.
SELECT * FROM employees WHERE upper(first_name) like '%DE%';

-- 22.
SELECT * FROM tblinsa WHERE to_char(ibsadate, 'mm') in ('07', '08', '09');

-- 24.
SELECT * FROM tblinsa 
    WHERE buseo in ('영업부', '총무부', '개발부')
        and jikwi in ('사원', '대리') and tel like '010%';

-- 25.
SELECT * FROM tblinsa
    WHERE to_char(ibsadate, 'yyyy') between 2008 and 2010;
    
-- 26.
SELECT * FROM employees WHERE department_id is null;

-- 27.
SELECT job_id FROM employees group by job_id;

-- 28.
SELECT * FROM employees;
SELECT department_id FROM employees WHERE to_char(hire_date,'yyyy') between 2002 and 2004;

-- 33.
SELECT * FROM tblCountry;
SELECT count(*) FROM tblCountry WHERE continent in ('EU', 'AS');

-- 36.
SELECT * FROM tblinsa;
SELECT count(tel) FROM tblinsa WHERE tel not like '010%';

-- 44.
SELECT * FROM tblCountry;
SELECT avg(population) FROM tblCountry WHERE continent = 'AS';

-- 48.
SELECT max(area) FROM tblCountry;

-- 50.
SELECT * FROM tblinsa;
SELECT name, substr(ssn,1,2) FROM tblinsa ORDER BY substr(ssn,1,2);

-- 52.
SELECT * FROM tblinsa;
SELECT distinct(substr(name,1,1)) FROM tblinsa WHERE jikwi in ('과장', '부장');

-- 53.
SELECT * FROM tblinsa ORDER BY to_char(ibsadate, 'mm');

-- 54.
SELECT * FROM tblinsa ORDER BY substr(ssn,8,1), name;

-- 55.
SELECT * FROM employees ORDER BY length(first_name||last_name) desc;

-- 56.
SELECT max(length(first_name||last_name)) FROM employees;

-- 57.
SELECT length(first_name) FROM employees WHERE length(last_name) = 4;

-- 58.
SELECT max(population), min(population), max(area), min(area) FROM tblCountry;

-- 59.
SELECT job_id,count(*) FROM employees GROUP BY job_id;

-- 60.
SELECT buseo,count(*) FROM tblinsa GROUP BY buseo ORDER BY count(*) desc;

-- 63.
SELECT substr(name, 1,1),count(*) FROM tblinsa GROUP BY substr(name, 1,1);        

-- 65.
SELECT * FROM tblinsa;
SELECT buseo as 부서, count(*), 
    count(case
        when jikwi = '부장' then 1
    end) as 부장,
    count(case
        when jikwi = '과장' then 1
    end) as 과장,
    count(case
        when jikwi = '대리' then 1
    end) as 대리,
    count(case
        when jikwi = '사원' then 1
    end) as 사원
FROM tblinsa GROUP BY buseo;

-- 66.
SELECT * FROM tblinsa;
SELECT city, count(*) FROM tblinsa GROUP BY city HAVING count(*) > 10;

-- 67.
SELECT * FROM tblcountry;
SELECT name FROM tblcountry WHERE population = (SELECT max(population) FROM tblcountry);

-- 75.
SELECT * FROM employees;
SELECT * FROM departments;
SELECT * FROM locations;
SELECT * FROM employees WHERE department_id = 
(SELECT department_id FROM departments WHERE location_id = 
(SELECT location_id FROM locations WHERE city = 'London'));
    
-- 76.
SELECT * FROM tblinsa;
SELECT * FROM tblinsa
    WHERE buseo in (SELECT buseo FROM tblinsa WHERE sudang >= 210000);


-- 77.
SELECT * FROM tblDiary;
SELECT weather,COUNT(*) FROM tblDiary GROUP BY weather ORDER BY COUNT(*) desc;

-- 78.
SELECT * FROM tblHouseKeeping;
SELECT * FROM tblHouseKeeping ORDER BY price * qty desc;

-- 79.
SELECT * FROM tblZoo;
SELECT family, avg(leg) FROM tblZoo GROUP BY family;

-- 80.
SELECT 
    count(case
        when breath = 'gill' then 1
    end) as 아가미,
    count(case
        when breath = 'lung' then 1
    end) as 폐호흡
    FROM tblZoo WHERE thermo = 'variable';

-- 81.
SELECT sizeof, family, count(*) FROM tblZoo GROUP BY sizeof, family;

-- 82.
SELECT * FROM tblMen;
SELECT * FROM tblWomen;
SELECT m.name, m.height, m.weight, w.name, w.height, w.weight
    FROM tblMen m
        INNER JOIN tblWomen w
            ON m.couple = w.name;
            
-- 83.
SELECT * FROM tblTodo;
SELECT 
    count(case
        when completedate is null then 1
    end) as 완료하지않은일,
    count(case
        when completedate is not null then 1
    end) as 완료한일
        FROM tblTodo;

-- 84.
SELECT * FROM tblAddressBook;
SELECT 
    count(
        case
            when age/10 = 1 then 1
        end
    ) as "10대",
    count(
        case
            when age/10 = 2 then 1
        end
    ) as "20대",
    count(
        case
            when age/10 = 3 then 1
        end
    ) as "30대",
    count(
        case
            when age/10 = 4 then 1
        end
    ) as "40대"
        FROM tblAddressBook
            WHERE substr(address,1,2) = '서울';

-- 85.
SELECT * FROM tblAddressBook WHERE address like '%' || hometown || '%';

-- 86.
SELECT * FROM tblAddressBook;
SELECT * FROM tblAddressBook WHERE address like '%역삼로%' and email like '%@gmail.com';


--87. tblAddressBook. 가장 많은 사람들이 가지고 있는 직업은 주로 어느 지역 태생(hometown)인가?
SELECT * FROM tblAddressBook;


SELECT job FROM
    (SELECT job, count(*)
        FROM tblAddressBook
            GROUP BY job
                ORDER BY job DESC)
                    WHERE rownum = 1;
                    
SELECT hometown FROM
    (SELECT hometown FROM tblAddressBook
        WHERE job = (SELECT job FROM
        (SELECT job, count(*)
            FROM tblAddressBook
                GROUP BY job
                    ORDER BY job DESC)
                        WHERE rownum = 1))
                        WHERE rownum = 1;


--88. tblAddressBook. 전화번호에 '123'이 들어간 사람 중 여학생만을 가져오시오.
SELECT * FROM tblAddressBook WHERE tel LIKE '%123%' and gender = 'f';

--89. tblAddressBook. 관리자의 실수로 몇몇 사람들의 이메일 주소가 중복되었다. 중복된 이메일 주소만 가져오시오.
SELECT * FROM tblAddressBook;

SELECT email
    FROM tblAddressBook
        GROUP BY email
            HAVING count(*) >= 2;

--90. tblAddressBook. 이메일 도메인들 중 평균 아이디 길이가 가장 긴 이메일 사이트의 도메인은 무엇인가?
select * from tblAddressBook;

SELECT 도메인 FROM
(SELECT substr(email, instr(email,'@')+1, length(email) - instr(email, '@'))as 도메인,count(*)
    , avg(length(substr(email, 1, instr(email, '@')))) 
    FROM tblAddressBook
        GROUP BY substr(email, instr(email,'@')+1, length(email) - instr(email, '@'))
        ORDER BY avg(length(substr(email, 1, instr(email, '@')))) desc)
        WHERE rownum = 1;

SELECT avg(length(substr(email, 1, instr(email, '@'))))
    FROM tblAddressBook
        GROUP BY (SELECT substr(email, instr(email,'@')+1, length(email) - instr(email, '@'))
    FROM tblAddressBook
        GROUP BY substr(email, instr(email,'@')+1, length(email) - instr(email, '@')));

--91. tblAddressBook. 평균 나이가 가장 많은 출신(hometown)들이 가지고 있는 직업 중 가장 많은 직업은?
SELECT * FROM tblAddressBook;

select tel
    from tblAddressBook
        group by tel
            having tel like '010%';

SELECT hometown, avg(age) FROM tblAddressBook
    GROUP BY hometown
        order by avg(age) desc;


SELECT hometown FROM tblAddressBook
    GROUP BY hometown
        HAVING avg(age) = (SELECT max(avg(age)) FROM tblAddressBook
    GROUP BY hometown);
    
SELECT job FROM(
    SELECT job,count(*) FROM tblAddressBook
        WHERE hometown = 
        (SELECT hometown FROM tblAddressBook GROUP BY hometown
            HAVING avg(age) = (SELECT max(avg(age)) FROM tblAddressBook GROUP BY hometown))
                GROUP BY job
                    ORDER BY count(*) desc)
                        WHERE rownum =1;
    
SELECT 
    FROM tblAddress

--92. tblAddressBook. 성씨별 인원수가 100명 이상 되는 성씨들을 가져오시오.;
SELECT * FROM tblAddressBook;
SELECT  substr(name,1,1), count(*)
    FROM tblAddressBook
        GROUP BY substr(name,1,1)
            HAVING count(*) >=100;

--93. tblAddressBook. 남자 평균 나이보다 나이가 많은 서울 태생 + 직업을 가지고 있는 사람들을 가져오시오.
SELECT * FROM tblAddressBook;

SELECT * FROM tblAddressBook WHERE age > (SELECT avg(age) FROM tblAddressBook WHERE gender = 'm')
    and hometown = '서울' and job is not null;

--94. tblAddressBook. 
--이메일이 스네이크 명명법으로 만들어진 사람들 중에서 여자이며, 20대이며, 키가 150~160cm 사이며, 고향이 서울 또는 인천인 사람들만 가져오시오.
SELECT * FROM tblAddressBook;

SELECT * FROM tblAddressBook
    WHERE instr(email,'_') > 0 and gender = 'f' and height between 150 and 160 and hometown in ('서울', '인천');

--95. tblAddressBook. gmail.com을 사용하는 사람들의 성별 > 세대별(10,20,30,40대) 인원수를 가져오시오.
SELECT * FROM tblAddressBook;

SELECT age, age/10 FROM tblAddressBook
    WHERE email like '%gmail.com';

SELECT gender,
    count(
        case
            when floor(age/10) = 1 then 1
        end
    ) as "10대",
    count(
        case
            when floor(age/10) = 2 then 1
        end
    ) as "20대",
    count(
        case
            when floor(age/10) = 3 then 1
        end
    ) as "30대",
    count(
        case
            when floor(age/10) = 4 then 1
        end
    ) as "40대"
    FROM (SELECT * FROM tblAddressBook
    WHERE email like '%gmail.com')
        GROUP BY gender;

--96. tblAddressBook. 가장 나이가 많으면서 가장 몸무게가 많이 나가는 사람과 같은 직업을 가지는 사람들을 가져오시오.
SELECT * FROM tblAddressBook;

SELECT * FROM tblAddressBook
    WHERE job = (SELECT job 
        FROM tblAddressBook
            WHERE (age, weight) = (SELECT max(age), max(weight) FROM tblAddressBook ));


--97. tblAddressBook. '건물주'와 '건물주자제분'들의 거주지가 서울과 지방의 비율이 어떻게 되느냐?
SELECT 
    count(
        case
            when address like '%서울%' then 1
        end)/count(*)*100 as 서울비율,
        count(
        case
            when address not like '%서울%' then 1
        end)/count(*)*100 as 지방비율
            FROM tblAddressBook
                WHERE job = '건물주' or job = '건물주자제분';
    
SELECT count(*)
    FROM (SELECT address FROM tblAddressBook
    WHERE job = '건물주' or job = '건물주자제분') a
        WHERE a.address like '%서울%' ;
        
SELECT count(*)
    FROM (SELECT address FROM tblAddressBook
    WHERE job = '건물주' or job = '건물주자제분') a
        WHERE a.address not like '%서울%' ;

--98. tblAddressBook.  동명이인이 여러명 있습니다. 이 중 가장 인원수가 많은 동명이인(모든 이도윤)의 명단을 가져오시오.
SELECT * FROM tblAddressBook;

SELECT * FROM tblAddressBook
    WHERE name = (SELECT distinct name FROM ((SELECT name, count(*)
        FROM tblAddressBook
            GROUP BY name
                ORDER BY count(*) desc)) WHERE rownum=1);

--99. tblAddressBook. 가장 사람이 많은 직업의(332명) 세대별 비율을 구하시오.
--    [10대]       [20대]       [30대]       [40대]
--    8.7%        30.7%        28.3%        32.2%
SELECT * FROM tblAddressBook;

SELECT job 
    FROM(SELECT job, count(*)
        FROM tblAddressBook
            GROUP BY job
                ORDER BY count(*) DESC)
                    WHERE rownum = 1;

SELECT 
    round(count(
        case
            when trunc(age/10) = 1 then 1
        end
        )/count(*) * 100,1) || '%' as "10대",
    round(count(
        case
            when trunc(age/10) = 2 then 1
        end
        )/count(*) * 100,1) || '%' as "20대",
    round(count(
        case
            when trunc(age/10) = 3 then 1
        end
        )/count(*) * 100,1) || '%' as "30대",
    round(count(
        case
            when trunc(age/10) = 4 then 1
        end
        )/count(*) * 100,1) || '%'  as "40대"
            FROM tblAddressBook
                WHERE job = (SELECT job 
    FROM(SELECT job, count(*)
        FROM tblAddressBook
            GROUP BY job
                ORDER BY count(*) DESC)
                    WHERE rownum = 1);

