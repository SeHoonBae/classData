-- ex14_casting

/*

형변환, Casting

1. to_char() : 숫자 -> 문자 // 사용 빈도 낮음
2. to_char() : 날짜 -> 문자 // 사용 빈도 높음(***)
3. to_number() : 문자 -> 숫자 
4. to_date() : 문자 -> 날짜 

1. to_char()
- char to_char(컬럼명, 형식문자열)

형식문자열 구성 요소
a. 9 -> 9 개수만큼 자리를 차지 부족한 자리는 공백으로 채우지만 9개수보다 컬럼값의 자리수가 크면 # 반환
b. 0 -> 0 개수만큼 자리를 차지 부족한 자리는 0으로 채우지만 0개수보다 컬럼값의 자리수가 크면 # 반환
c. $ -> $ 를 맨앞에 붙임 1개만 가능, 1개 이상은 에러
d. L -> Locale(지역 설정에 맞는 표현을 사용), 단위(원)을 붙여주며 1개만 가능, 1개 이상은 에러
e. . : 소수점 표시
f. , : 천단위 표시

*/
SELECT 100 as aaaaaaaaaaaa, '100' as bbbbbbbbbbbbbbbbbbb FROM dual;
SELECT 100 + 200, '100' + 200 FROM dual; -- 암시적 형변환

SELECT to_char(100) FROM dual; -- 100 -> '100' //String.valuOf(100) -> "100"
SELECT to_char(100, '999') FROM dual;
SELECT to_char(100, '0000') FROM dual;
SELECT to_char(100, 'L0000') FROM dual;

SELECT weight || 'kg' FROM tblcomedian;
SELECT to_char(weight,'999') FROM tblcomedian;

SELECT to_char(123.456, '999.9999') FROM dual;
SELECT to_char(123.456, '999.99') FROM dual; -- 반올림 처리

SELECT to_char(1000000,'9,999,999') FROM dual;

/*
2. to_char() : 날짜 -> 문자
- char to_char(컬럼명, '형식 문자열')
- 컬럼명 : 날짜(date)

형식 문자열 구성 요소
a. yyyy
b. yy
c. month
d. mon
e. mm
f. day
g. dy
h. ddd, dd, d
i. hh(hh12), hh24
j. mi
k. ss
l. am(pm)
*/

SELECT sysdate FROM dual;
SELECT to_char(sysdate, 'yyyy') FROM dual; -- 2019년(4자리)
SELECT to_char(sysdate, 'yy') FROM dual; --19년(2자리) X
SELECT to_char(sysdate, 'month') FROM dual; -- 3월(로케일), March
SELECT to_char(sysdate, 'mm') FROM dual; -- 03(*****)
SELECT to_char(sysdate, 'day') FROM dual; -- 목요일(로케일) 풀네임
SELECT to_char(sysdate, 'dy') FROM dual; -- 목(로케일) 약어
SELECT to_char(sysdate, 'ddd') FROM dual; -- 080 올해들어 며칠 지났는지?
SELECT to_char(sysdate, 'dd') FROM dual; -- 21 이번달 들어 며칠 지났는지?(***)
SELECT to_char(sysdate, 'd') FROM dual; -- 5 이번 주 들어 며칠 지났는지?(요일)
SELECT to_char(sysdate, 'hh') FROM dual; -- 12시간 표기
SELECT to_char(sysdate, 'hh24') FROM dual; -- 24시간 표기(***)
SELECT to_char(sysdate, 'mi') FROM dual; 
SELECT to_char(sysdate, 'ss') FROM dual; 
SELECT to_char(sysdate, 'am') FROM dual; 
SELECT to_char(sysdate, 'pm') FROM dual; 

-- 자주 쓰는 패턴
SELECT sysdate FROM dual;
SELECT to_char(sysdate, 'yyyy-mm-dd') FROM dual;

SELECT name, to_char(ibsadate, 'yyyy-mm-dd')FROM tblinsa;

-- 조건으로 사용
-- 12월에 입사한 직원들?
SELECT * FROM tblinsa WHERE to_char(ibsadate, 'mm') = '12';
SELECT * FROM tblinsa WHERE to_char(ibsadate, 'yyyy') = '2010';

SELECT * FROM tblinsa WHERE to_char(ibsadate, 'yyyy-mm') = '2009-12';

-- 정렬로 사용
-- 고참 ~ 신참
SELECT * FROM tblinsa ORDER BY ibsadate asc;
SELECT * FROM tblinsa ORDER BY to_char(ibsadate,'mm') asc;

/*
3. to_number() : 문자 -> 숫자

*/


/*
4. to_date() : 문자 -> 날짜
- date to_date(컬럼명, '형식문자열')
- 형식 문자열 구성요소가 위의 2번과 동일
*/

-- 오라클(SQL)은 문맥에 따라 날짜 상수(문자열)를 문자열로 취급하는 경우와 date로 취급하는 경우가 있다.
SELECT sysdate, '2019-03-21', add_months('2019-03-21',1) FROM dual; --문자열
SELECT * FROM tblinsa WHERE ibsadate < '2019-03-21'; -- 날짜(문자열) 암시적 형변환 발생

-- 시,분,초 추가 -> 암시적 형변환 불가능(DB설정 & 툴 포맷 - 가능O, 불가능O) -> 결론 : 불가능
SELECT title, adddate, to_char(adddate, 'yyyy-mm-dd hh24:mi:ss') FROM tbltodo
--WHERE adddate > '2019-03-05 12:30:00';
--WHERE adddate > to_date('2019-03-05 12:30:00', 'yyyy-mm-dd hh24:mi:ss');
WHERE adddate > to_date('2019-03-05 12:30:00', 'yyyymmdd hh24miss');

SELECT 
    sysdate, 
    to_date('2019-03-21', 'yyyy-mm-dd') , -- 자정으로 세팅(기억!!)
    to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
    to_char(to_date('2019-03-21', 'yyyy-mm-dd'), 'yyyy-mm-dd hh24:mi:ss'), -- 자정으로 맞춰짐
    to_date('15:30:45', 'hh24:mi:ss') -- 해당월의 1일로 자동지정됨
FROM dual;


