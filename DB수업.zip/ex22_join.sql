-- ex22_join

/*

-- 조인, join + 테이블간의 관계(***)


*/

-- 직원 + 담당 프로젝트 > 테이블 생성

DROP TABLE tblStaff;

CREATE TABLE tblStaff
(
    seq number primary key, -- 직원 번호
    name varchar2(30) not null, -- 직원명
    salary number not null, -- 급여
    address varchar(300) not null, -- 거주지
    projectname varchar2(100) null -- 이 직원이 담당하는 프로젝트명
);

INSERT INTO tblStaff (seq, name, salary, address, projectname)
    values (1, '홍길동', 250, '서울시', '홍콩 수출');

INSERT INTO tblStaff (seq, name, salary, address, projectname)
    values (2, '아무개', 230, '부산시', 'TV 광고');
    
INSERT INTO tblStaff (seq, name, salary, address, projectname)
    values (3, '하하하', 210, '서울시', '매출 분석');

-- 정책 : 직원 1명이 여러 프로젝트를 담당하는게 가능.

INSERT INTO tblStaff (seq, name, salary, address, projectname)
    values (4, '홍길동', 250, '서울시', 'TV 광고');

INSERT INTO tblStaff (seq, name, salary, address, projectname)
    values (5, '홍길동', 250, '서울시', '자재 납품');

select * from tblStaff;

-- 관계형 데이터베이스(오라클)에서 1개의 셀안에는 분리될 수 없는 원자값이 들어있어야 한다.
UPDATE tblStaff SET 
    projectname = '홍콩 수출, 인사 처리, 자재 납품'
        WHERE seq = 1;

DELETE FROM tblStaff WHERE seq in (4, 5);

DROP TABLE tblStaff;
DROP TABLE tblProject;
-- 직원 테이블, 위에 있는 테이블은 잘못된 테이블임.
CREATE TABLE tblStaff
(
    seq number primary key, -- 직원 번호
    name varchar2(30) not null, -- 직원명
    salary number not null, -- 급여
    address varchar(300) not null -- 거주지
);

-- 프로젝트 테이블
CREATE TABLE tblProject
(
    seq number primary key, -- 프로젝트 번호(PK)
    projectname varchar2(100) not null, -- 프로젝트 명
    staffseq number not null -- 담당직원 번호
);

INSERT INTO tblStaff (seq, name, salary, address)
    values(1, '홍길동', 250, '서울시');

INSERT INTO tblStaff (seq, name, salary, address)
    values(2, '아무개', 230, '부산시');

INSERT INTO tblStaff (seq, name, salary, address)
    values(3, '하하하', 270, '서울시');

INSERT INTO tblProject (seq, projectname, staffseq) values (1, '홍콩 수출', 1); -- 홍길동
INSERT INTO tblProject (seq, projectname, staffseq) values (2, 'TV 광고', 2); -- 아무개
INSERT INTO tblProject (seq, projectname, staffseq) values (3, '매출 분석', 3); -- 하하하
INSERT INTO tblProject (seq, projectname, staffseq) values (4, '노조 협상', 1); -- 홍길동
INSERT INTO tblProject (seq, projectname, staffseq) values (5, '대리점 분양', 1); -- 홍길동

SELECT * FROM tblProject;
SELECT * FROM tblStaff;

-- 서로 관계를 맺고 있는 두 테이블간의..
-- tblStaff(기본 테이블, 부모 테이블)
-- tblProject(참조 테이블, 자식 테이블)

-- *** 관계를 맺고 있는 2개의 테이블의 데이터를 조작하면.. 생기는 일들..
-- 이 부분을 실수하면 > 데이터의 무결성(유효성)이 깨진다. > 데이터의 가치가 상실된다.
-- 1. 부모 테이블의 조작
--  a. 행 추가 : 아무 제약 없음
--  b. 행 수정 : 아무 제약 없음
--  c. 행 삭제 : 자식 테이블에 나를 참조하고 있는 행이 존재하는지 체크
-- 2. 자식 테이블의 조작
--  a. 행 추가 : 참조하는 컬럼값이 부모 테이블 존재하는 값인지 체크(직원 번호)
--  b. 행 수정 : 참조하는 컬럼값이 부모 테이블 존재하는 값인지 체크(직원 번호)
--  c. 행 삭제  : 아무 제약 없음


-- 외래키(참조키), Foreign Key
-- 참조 관계에 있는 두 테이블간의 연결 고리 역할을 하는 컬럼(키)이 있다.
-- 그 컬럼에게 항상 유효한 값을 저장할 수 있도록 동작하는 제약 사항
-- 부모테이블(PK) <-> 자식테이블(FK)

SELECT * FROM tblProject; -- 5건
SELECT * FROM tblStaff; -- 3명

-- A. 신입 사원 입사 > 신규 프로젝트 담당
-- A.1 신입 사원 추가
INSERT INTO tblStaff (seq, name, salary, address)
    values(4, '호호호', 200, '인천시');
-- A.2 신규 프로젝트 추가
INSERT INTO tblProject (seq, projectname, staffseq) values (6, '자재 매입', 4);

-- A.3 신규 프로젝트 추가 > 잘못된 경우(!!!), 해당 직원번호를 가진 직원이 없는데 값을 추가함
INSERT INTO tblProject (seq, projectname, staffseq) values (7, '고객 유치', 5);

-- B. '홍길동' 퇴사
-- B.1 '홍길동' 삭제
DELETE FROM tblStaff WHERE seq = 1;

-- C.1 업무 인수 인계 > '홍길동' 프로젝트 > 다른 직원에게 위임
UPDATE tblProject SET staffseq = 2 WHERE staffseq = 1;

-- C.2 '홍길동' 퇴사
DELETE FROM tblStaff WHERE seq = 1;

-- 기본 테이블과 참조 테이블을 연결
CREATE TABLE tblStaff
(
    seq number primary key, -- 직원 번호
    name varchar2(30) not null, -- 직원명
    salary number not null, -- 급여
    address varchar(300) not null -- 거주지
);

CREATE TABLE tblProject
(
    seq number primary key, -- 프로젝트 번호(PK)
    projectname varchar2(100) not null, -- 프로젝트 명
    staffseq number not null REFERENCES tblStaff(seq) -- 담당직원 번호, 제약사항(Foreign Key)
);

INSERT INTO tblStaff (seq, name, salary, address)
    values(1, '홍길동', 250, '서울시');

INSERT INTO tblStaff (seq, name, salary, address)
    values(2, '아무개', 230, '부산시');

INSERT INTO tblStaff (seq, name, salary, address)
    values(3, '하하하', 270, '서울시');

INSERT INTO tblStaff (seq, name, salary, address)
    values(4, '호호호', 210, '서울시');

INSERT INTO tblProject (seq, projectname, staffseq) values (1, '홍콩 수출', 1); -- 홍길동
INSERT INTO tblProject (seq, projectname, staffseq) values (2, 'TV 광고', 2); -- 아무개
INSERT INTO tblProject (seq, projectname, staffseq) values (3, '매출 분석', 3); -- 하하하
INSERT INTO tblProject (seq, projectname, staffseq) values (4, '노조 협상', 1);
INSERT INTO tblProject (seq, projectname, staffseq) values (5, '대리점 분양', 1);
INSERT INTO tblProject (seq, projectname, staffseq) values (6, '자재 매입', 4);

-- ORA-02291: integrity constraint (HR.SYS_C007128) violated - parent key not found
INSERT INTO tblProject (seq, projectname, staffseq) values (7, '고객 유치', 5);

SELECT * FROM tblProject; -- 5건
SELECT * FROM tblStaff; -- 3명

-- ORA-02292: integrity constraint (HR.SYS_C007128) violated - child record found
DELETE FROM tblStaff WHERE seq = 1;

UPDATE tblProject SET staffseq = 2 WHERE staffseq = 1;


-- 관계 맺은 테이블들
-- 고객 <-> 판매
-- 고객 테이블(부모)
CREATE TABLE tblCustomer
(
    seq NUMBER PRIMARY KEY, -- 고객번호(pk)
    name VARCHAR2(30) NOT NULL, -- 고객명
    tel VARCHAR2(15) NOT NULL, -- 연락처
    address VARCHAR2(100) NOT NULL -- 주소
);

-- 판매 테이블(자식)
CREATE TABLE tblSales
(
    seq NUMBER PRIMARY KEY, -- 판매번호(PK)
    item VARCHAR2(50) NOT NULL, -- 상품명
    qty NUMBER NOT NULL, -- 판매수량
    regdate DATE DEFAULT sysdate NOT NULL, -- 판매날짜
    customerseq NUMBER NOT NULL REFERENCES tblCustomer(seq)
);

-- 관계 맺은 테이블 경우
-- 생성 : 부모 -> 자식 순서
-- 삭제 : 자식 -> 부모 순서

DROP TABLE tblCustomer;
DROP TABLE tblSales;

-- 비디오 판매점
-- 장르 테이블
CREATE TABLE tblGenre
(
    seq NUMBER PRIMARY KEY, -- 장르번호
    name VARCHAR2(30) NOT NULL, -- 장르명
    price NUMBER NOT NULL, -- 대여 가격
    period NUMBER NOT NULL -- 대여 기간
);

-- 비디오 테이블
CREATE TABLE tblVideo
(
    seq NUMBER PRIMARY KEY, -- 비디오 번호(PK)
    name VARCHAR2(100) NOT NULL, -- 제목
    qty NUMBER NOT NULL, -- 보유 수량
    company VARCHAR2(50) NULL, -- 제작사
    director VARCHAR2(50) NULL, -- 감독
    major VARCHAR2(50) NULL, -- 주연배우
    genre NUMBER NOT NULL REFERENCES tblGenre(seq) -- 장르번호
);

-- 회원 테이블
CREATE TABLE tblMember
(
    seq NUMBER PRIMARY KEY, -- 회원번호
    name VARCHAR2(20) NOT NULL, -- 회원명
    grade NUMBER(1) NOT NULL, -- 회원등급(1,2,3)
    byear NUMBER(4) NOT NULL, -- 생년
    tel VARCHAR2(15) NOT NULL, -- 연락처
    address VARCHAR2(300) NULL, -- 주소
    money NUMBER NOT NULL -- 예치금
);

--  대여 테이블
CREATE TABLE tblRent
(
    seq NUMBER PRIMARY KEY, -- 대여번호(PK)
    member NUMBER NOT NULL REFERENCES tblMember(seq), -- 대여한 회원번호(FK)
    video NUMBER NOT NULL REFERENCES tblVideo(seq), -- 대여한 비디오번호(FK)
    rentdate DATE DEFAULT sysdate NOT NULL, -- 대여날짜
    retdate DATE NULL, -- 반납 날짜
    remart VARCHAR2(500) -- 비고
);

-- 시퀀스 객체
CREATE SEQUENCE memberSeq;
CREATE SEQUENCE genreSeq;
CREATE SEQUENCE videoSeq;
CREATE SEQUENCE rentSeq;

/*

조인, JOIN
- 2개(1개) 이상의 테이블의 내용을 한번에 가져와서 1개의 결과셋을 만드는 작업
- 분리되어 있는 2개 이상의 테이블을 1개로 만드는 작업(테이블 합치기)
- 단, 테이블간의 관계를 맺고 있어야만 한다.

조인의 종류(ANSI SQL)
1. 단순 조인, CROSS JOIN
2. 내부 조인, INNER JOIN
3. 외부 조인, OUTER JOIN
4. 셀프 조인, SELF JOIN


*/

--1. 단순 조인, CROSS JOIN
SELECT * FROM tblCustomer; -- 부모, 3명
SELECT * FROM tblSales; -- 자식, 9건

SELECT * FROM tblCustomer CROSS JOIN tblSales; -- ANSI 표현(표준)
SELECT * FROM tblCustomer, tblSales; -- Oracle 표현

/*

2. 내부 조인, INNER JOIN
- 단순 조인에서 유효한 레코드만 취하는 조인
- 부모 테이블의 PK와 자식 테이블의 FK가 동일한 레코드만 취하는 조인
SELECT 컬럼리스트 FROM 테이블A 
    INNER JOIN 테이블B 
        ON 테이블A.컬럼명 = 테이블B.컬럼명;

*/
-- INNER JOIN의 결과 레코드 수도 미리 예측 가능하다. > 자식 테이블 레코드 수와 동일
-- 구매내역과 그 구매한 손님 정보를 같이 가져오시오.

SELECT * FROM tblCustomer
    INNER JOIN tblSales
        ON tblcustomer.seq = tblsales.customerseq
            ORDER BY tblsales.customerseq;
-- 순서를 바꿔도 컬럼리스트 순서는 바뀌지만 내용은 같음 아무 의미가 없다.
SELECT * FROM tblSales
    INNER JOIN tblCustomer
        ON tblsales.customerseq = tblcustomer.seq
            ORDER BY tblsales.customerseq;

-- ORA-00918: column ambiguously defined , 컬럼이 누구껀지를 알수가없음
SELECT * FROM tblCustomer
    INNER JOIN tblSales
        ON seq = customerseq;

-- 일부 컬럼만 가져오기
SELECT tblCustomer.name, tblsales.item, tblSales.qty FROM tblCustomer
    INNER JOIN tblSales
        ON tblcustomer.seq = tblsales.customerseq
            ORDER BY tblsales.customerseq;

-- 테이블에도 별칭을 붙여 나타낼 수 있다.

SELECT c.name, s.item, s.qty FROM tblCustomer c
    INNER JOIN tblSales s
        ON c.seq = s.customerseq
            ORDER BY s.customerseq;

-- * 을 다른 것과 같이 쓸때는 테이블명.* 로 함
SELECT c.name, tel FROM tblCustomer c;
SELECT c.*, length(name) FROM tblCustomer c;

-- 2개 테이블 > 합쳐서 > 1개 결과셋?? 양쪽에 관련 있는 행들끼리 연결하려고

-- 표준 SQL
SELECT * FROM tblCustomer c
    INNER JOIN tblSales s
        ON c.seq = s.customerseq; -- 부모테이블(PK) = 자식테이블(FK)
        
-- 오라클
SELECT * FROM tblCustomer c, tblSales s
    WHERE c.seq = s.customerseq;

-- 조인 사용 시 반드시 관계있는 테이블끼리만 묶자 > 반드시 부모-자식 테이블간에만 한다.
SELECT * FROM tblCustomer;
SELECT * FROM tblProject;

SELECT * FROM tblCustomer c
    INNER JOIN tblProject p
        on c.seq = p.staffseq;

-- 질의 > 2개 이상 테이블이 관계되었다.
--  a. 서브쿼리 : 결과셋이 1개의 테이블로부터
--  b. 조인 : 결과셋이 2개의 이상의 테이블로부터

-- 노트(tblSales)를 사간 회원(tblCustomer)의 연락처 + 몇개?
-- 1. 서브쿼리
SELECT * FROM tblSales
    WHERE item = '노트';
    
SELECT * FROM tblCustomer
    WHERE seq = (SELECT customerseq FROM tlbcustomer.seq)
    WHERE item = '노트';);
    
SELECT name, tel, (select qty from tblSales where customerseq = tblCustomer.seq and item = '노트') FROM tblCustomer
    WHERE seq = (SELECT customerseq FROM tblCustomer WHERE item = '노트');

--2. 조인
SELECT c.name, c.tel, s.qty FROM tblCustomer c
    INNER JOIN tblSales s
            ON c.seq = s.customerseq
                WHERE s.item = '노트';

SELECT * FROM tblCustomer; -- 3명
SELECT * FROM tblSales; -- 9건

-- 회원 1명 가입
INSERT INTO tblCustomer values( 4, '호호호', '010-2937-1234', '서울시');

-- 평범한 내부 조인
-- ** '호호호'가 없다
SELECT * FROM tblCustomer c
    INNER JOIN tblSales s
        ON c.seq = s.customerseq;

-- 쇼핑몰의 구매 내역과 상관없이 모든 회원을 가져와라~~ + 단, 구매이력이 있다면 그것도 같이
/*
3. 외부조인, OUTER JOIN
*/
-- 표준 SQL
SELECT * FROM tblCustomer c
    LEFT OUTER JOIN tblSales s
        ON c.seq = s.customerseq;
        
-- 오라클
SELECT * FROM tblCustomer c, tblSales s 
    WHERE c.seq = s.customerseq(+);

SELECT * FROM tblMen;
SELECT * FROM tblWomen;

SELECT m.name, w.name FROM tblMen m
    Inner join tblWomen w
        on m.name = w.couple;

SELECT m.name, w.name FROM tblMen m
    LEFT OUTER JOIN tblWomen w
        on m.name = w.couple;

SELECT m.name, w.name FROM tblMen m
    RIGHT OUTER JOIN tblWomen w
        on m.couple = w.name;

/*
4. 셀프 조인, SELF JOIN
- 1개의 테이블을 사용해 조인 + 내부,외부 조인
- 자기가 자기를 참조하는 경우에 사용(빈도 낮음) > ex) 재귀메소드
*/

-- 직원 테이블
CREATE TABLE tblSelf
(
    seq NUMBER PRIMARY KEY, -- 직원번호(PK)
    name VARCHAR2(30) NOT NULL, -- 직원명
    department VARCHAR2(30) NULL, -- 부서
    super number null REFERENCES tblSelf(seq) -- 직속상사번호(FK)
    
);

INSERT INTO tblSelf values (1,'홍사장',null,null);

INSERT INTO tblSelf values (2,'김부장','영업부',1);
INSERT INTO tblSelf values (3,'이과장','영업부',2);
INSERT INTO tblSelf values (4,'정대리','영업부',3);
INSERT INTO tblSelf values (5,'최사원','영업부',4);

INSERT INTO tblSelf values (6,'박부장','홍보부',1);
INSERT INTO tblSelf values (7,'하과장','홍보부',6);

select * from tblSelf;

-- 직원 명단(tblSelf) + 상사 정보(tblSelf) 같이 가져오시오.
-- inner join (레코드 개수는 자식이 중심)
SELECT s2.name as 직원명, s2.department as 부서, s1.name as 상사명 FROM tblSelf s1 -- 상사 테이블
    INNER JOIN tblSelf s2 -- 직원 테이블
        ON s1.seq = s2.super;

SELECT s2.name as 직원명, s2.department as 부서, s1.name as 상사명 FROM tblSelf s1 -- 상사 테이블
    RIGHT OUTER JOIN tblSelf s2 -- 직원 테이블
        ON s1.seq = s2.super;

SELECT e2.first_name as 직원, e1.first_name as 매니저 FROM employees e1
    LEFT OUTER JOIN employees e2
        ON e1.employee_id = e2.manager_id;

-- 테이블 1개
-- 비디오가 뭐뭐?
SELECT * FROM tblVideo;

-- 테이블 2개
-- 모든 비디오 정보(tblVideo) + 대여 가격 + 대여 기간(tblGenre)?
SELECT * FROM tblGenre g
    INNER JOIN tblVideo v
        ON g.seq = v.genre; -- tblGenre(seq) = tblVideo(genre)

-- 테이블 3개
SELECT * FROM tblGenre g
    INNER JOIN tblVideo v
        ON g.seq = v.genre -- A 관계 선
            INNER JOIN tblRent r
                ON r.video = v.seq; -- B 관계 선

-- 테이블 4개
SELECT * FROM tblGenre g
    INNER JOIN tblVideo v
        ON g.seq = v.genre -- A 관계 선
            INNER JOIN tblRent r
                ON r.video = v.seq -- B 관계 선
                    INNER JOIN tblMember m
                        ON m.seq = r.member ; --C 관계 선

-- OUTER JOIN(회원)
-- 대여기록의 유무와 상관없이 모든 회원 열람(대여기록 있다면 같이 열람)
SELECT * FROM tblGenre g
    INNER JOIN tblVideo v
        ON g.seq = v.genre -- A 관계 선
            INNER JOIN tblRent r
                ON r.video = v.seq -- B 관계 선
                    RIGHT OUTER JOIN tblMember m
                        ON m.seq = r.member ; --C 관계 선

-- ** 해당 쿼리가 뭘 질문하는지 문장을 만들기(*****)

-- OUTER JOIN(회원)
-- 대여기록에 상관없이 모든 비디오 정보 열람(대여기록 있다면 같이 열람)
SELECT * FROM tblGenre g
    INNER JOIN tblVideo v
        ON g.seq = v.genre -- A 관계 선
            LEFT OUTER JOIN tblRent r
                ON r.video = v.seq -- B 관계 선
                    LEFT OUTER JOIN tblMember m
                        ON m.seq = r.member ; --C 관계 선

-- 점포 주인 : 대여 기록 출력 > 회원명, 비디오제목, 언제, 반납 유무('반납완료' OR '미반납')

SELECT
    m.name as 회원명,
    v.name as 비디오제목,
    to_char(r.rentdate, 'yyyy-mm-dd') as 대여일,
    r.retdate as 반납일,
    case
        when r.retdate is not null then '반납완료'
        else '미반납'
    end as 반납유무,
    g.name,
    g.period,
    g.price,
    case
        when r.retdate is null then round(sysdate - r.rentdate + g.period)
        when r.retdate is not null then 0
    end as 연체기간,
    case
        when r.retdate is null then round(sysdate - r.rentdate + g.period) * (g.price * 0.05)
        when r.retdate is not null then 0
    end as 연체료
        FROM tblMember m
            INNER JOIN tblRent r
                ON m.seq = r.member
                    INNER JOIN tblVideo v
                        ON v.seq = r.video
                            INNER JOIN tblGenre g
                                ON g.seq = v.genre;

















-- 프로젝트 할 때
-- 데이터 백업 & 복구
-- 1. 스크립트 사용(권장)
--  a. CREATE 문
--  b. INSERT 문 (UPDATE + DELETE)

-- 2. 클라이언트 툴 사용
--  a. 백업 & 복구 기능






