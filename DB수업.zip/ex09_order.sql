-- ex09_order

/*

정렬, Sort
- 원본 테이블의 정렬이 아니다.(***** 원본 테이블 레코드 정렬은 오라클이 알아서 한다.)
- SELECT의 결과 테이블의 정렬이 중요하다. > order by 절을 사용한다.

ORDER BY 절
- 결과 셋을 정렬하는데 사용한다.
- 오름차순 정렬, 내림차순 정렬
- order by 컬럼명 asc(desc)
    - asc, ascending
        a. 숫자 : 10 11 12 ...
        b. 문자 : 가 나 다 ...
        c. 날짜 2016 2017 ...
    - desc, descending
        - 위와 반대 순서대로..

SELECT 문
- SELECT 컬럼리스트 FROM 테이블
- SELECT 컬럼리스트 FROM 테이블 WHERE 조건
- SELECT 컬럼리스트 FROM 테이블 WHERE 조건 ORDER BY 정렬

1. SELECT 컬럼리스트
    - 가져올 컬럼을 지정한다.
    - 가져올 값을 연산하기도 한다.
2. FROM 테이블
    - 테이블 선택한다.
3. WHERE 조건
    - 가져올 레코드를 지정한다.
4. ORDER BY 정렬
 - 가져올 레코드의 순서를 지정한다.
 
절 실행순서
- FROM(1) > WHERE(2) > ORDER BY (3) > SELECT(4)
 
*/

SELECT * FROM tblinsa ORDER BY name asc; -- 이름순으로 정렬(가나다)
SELECT * FROM tblinsa ORDER BY name desc; -- 이름순으로 정렬(다나가)



