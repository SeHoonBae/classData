-- ex29_hierarchicalQuery

/*

계층형 쿼리, Hierarchical Query
- 오라클 전용
- 답변형 게시판, 카테고리 관리, BOM(자재 명세서) 등에 적용
- 부모와 자식으로 구성된 트리 구조의 데이터를 처리하는 질의

컴퓨터
    - 본체
        - 메인보드
        - 그래픽카드
        - 랜카드
        - 메모리
    - 모니터
        - 보호필름
    - 프린터
        - 잉크카트리지
        - A4용지

*/
CREATE TABLE tblComputer
(
    seq NUMBER PRIMARY KEY, -- PK
    name VARCHAR2(100) NOT NULL, -- 요소명
    qty NUMBER NOT NULL, -- 수량
    PSEQ number references tblComputer(seq) null -- 부모부품(FK)
);

INSERT INTO tblComputer values (1, '컴퓨터', 1,null ); -- 루트 노드
INSERT INTO tblComputer values (2, '본체',1 , 1);
INSERT INTO tblComputer values (3, '모니터',1, 1);
INSERT INTO tblComputer values (4, '프린터',1, 1);
INSERT INTO tblComputer values (5, '메인보드',1, 2);
INSERT INTO tblComputer values (6, '그래픽카드', 1, 2);
INSERT INTO tblComputer values (7, '램카드', 1, 2);
INSERT INTO tblComputer values (8, '메모리카드', 2, 2);
INSERT INTO tblComputer values (9, '보호필름', 1, 3);
INSERT INTO tblComputer values (10, '잉크카트리지', 3, 4);
INSERT INTO tblComputer values (11, 'A4용지', 100, 4);

SELECT * FROM tblComputer;

--1. 셀프 조인 >부모 & 자식 밖에 표현 
SELECT c2.name as 부품, c1.name as 부모부품 FROM tblComputer c1
    RIGHT OUTER JOIN tblComputer c2
        on c1.seq = c2.pseq;

--2. 계층형 쿼리
-- start with 절 connect by 절
SELECT * FROM tblComputer
    start with seq = 1
        connect by prior seq = pseq;

-- 계층형 쿼리 > 의사 컬럼
SELECT seq, name, qty, pseq, level FROM tblComputer
    start with seq = 1
        connect by prior seq = pseq;

SELECT lpad(' ', (level - 1 ) * 5) || name FROM tblComputer
    start with seq = 1
        connect by prior seq = pseq;

SELECT lpad(' ', (level - 1 ) * 3) || name FROM tblComputer
    start with seq = 1 --루트 노드(출발점) 지정
        connect by prior seq = pseq; -- prior 컬럼 = 컬럼

-- 위 아래가 같다
SELECT lpad(' ', (level - 1 ) * 3) || name, prior name FROM tblComputer
    start with pseq is null --루트 노드(출발점) 지정
        connect by prior seq = pseq; -- prior 컬럼 = 컬럼


select lpad(' ', (level-1)*5) || subject from tblBoard
    start with pseq is null
        connect by prior seq = pseq
            --order by seq desc;                                                                      
            order siblings by seq desc;
        
SELECT * FROM tblCategory 
    START WITH pseq IS NULL
        connect by prior seq = pseq
            order silblings by name;
        
        
        
        
--    ORDER BY seq desc;
        
SELECT
    lpad(' ', (level-1)*3) || name as "현재 카테고리",
    prior name as "부모 카테고리",
    connect_by_root name as "루트 카테고리",
    connect_by_isleaf,
    sys_connect_by_path(name, '▶')
    from tblCategory
    start with pseq is null
        connect by prior seq = pseq
            order siblings by name asc;







