/*

연산자

1. 산술 연산자
- +, -, *, /
- %(없음) -> 함수로 제공(mod())

2. 문자열 연산자
- +(X) ||(O)

3. 비교 연산자
- >, >=, <, <=
- =(==), <>(!=) 첫번째가 오라클 ()안의 값이 자바
- 논리값을 결과값으로 반환
- 비교 연산자의 결과는 컬럼 리스트에 들어갈 수 없다.(출력 못함 - boolean 자료형이 없기 때문에)
- SQL 자료형에는 boolean이 없다.
- 조건절에서 사용한다.(where 절)

4. 논리 연산자
- and(&&), or(||), not(!) 첫번째가 오라클 ()안의 값이 자바
- 조건절에서 사용한다.
- 컬럼리스트에 넣을 수 없다.

5. 대입 연산자
- 없음
- 있음(변수 대신에 컬럼이 존재) -> 컬럼을 대상으로 수정 작업할 때 사용 -> update문
- 컬럼명(셀값) = 새로운 값
- 복합 대입 연산자(+=, -= 등등) 없음 -> weight += 1 (X) -> weight = weight + 1 (O)

6. 3항 연산자
- 없음
- 제어문이 없음
- 비슷한 행동을 하는 함수 몇개가 제공

7. 증감 연산자
- 없음
- ++(X) -> num = num + 1 (O)

8. SQL 연산자(절)
- 자바 : instanceof
- in, between, like, is, any, all 등..

*/

SELECT * FROM tblcomedian;

SELECT last, first, weight+10, height, weight/(height*height) * 10000 FROM tblcomedian;

SELECT last || first, weight+10, height "키", weight/(height*height) * 10000 FROM tblcomedian;

-- 컬럼 별칭(Alias) 만들기
-- : 식별자로 유효한 컬럼명 만들기
-- : 별명(X) -> 개명(O) : 이전 컬럼명은 더이상 사용되지 않는다.(*****)
SELECT 
    last || first as fullname,
    weight+10 AS WEIGHT, --원본 테이블의 컬럼명과 동일 -> 아무 상관없음. 
    height "키", 
    weight/(height*height) * 10000 AS BMI
FROM tblcomedian;

SELECT nick AS 별명 FROM tblcomedian;

SELECT nick "개그맨 별명" -- 사용자 비권장
FROM tblcomedian;

SELECT nick "select" FROM tblcomedian; -- 절대 비권장(쓰지말것) 키워드

SELECT height > weight FROM tblcomedian;
