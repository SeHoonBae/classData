/*

-- 조건절에 사용되는 구문(연산자 or 절)

between
- WHERE 절에서 사용(조건으로 사용)
- 범위 조건 지정
- 컬럼명 between 최솟값 and 최댓값
- 되도록 사용할 것(between 사용하지 말 것 - 속도 느림, 비용에 대한 상황에 따라 다름)
- 최솟값, 최댓값 : 포함(inclusive)

*/

-- 몸무게 60이상 ~ 80이하
SELECT last || first as fullname, weight FROM tblcomedian;
SELECT last || first as fullname, weight FROM tblcomedian WHERE weight between 60 and 80;

-- 비교 연산에 사용되는 자료형
-- 1. 숫자형
-- 2. 문자형 > str1.compareTo(str2)
-- 3. 날짜시간 > tick값

SELECT * FROM tblcomedian WHERE height > 170;
SELECT * FROM tblcomedian WHERE first > last; -- 문자형 직접 비교 가능
SELECT * FROM employees WHERE hire_date > '2003-01-01';

SELECT * FROM tblcomedian WHERE last > '다' and last < '자';
SELECT * FROM tblcomedian WHERE last between '다' and '자';

SELECT * FROM employees WHERE hire_date > '2003-01-01' and hire_date < '2003-12-31';
SELECT * FROM employees WHERE hire_date between '2003-01-01' and '2003-12-31';

SELECT * FROM tblcomedian WHERE height between 172 and 178;
SELECT * FROM tblcomedian WHERE not height between 172 and 178; -- not은 컬럼명 앞에


/*

in
-WHERE 절에서 사용(조건으로 사용)
- 열거형 조건(제시된 값중에서 하나라도 일치하면 만족)
- 컬럼명 in (열거형값)

*/

-- SQL은 대소문자를 구분하지 않지만 데이터 값은 구분한다.
-- AS + EU
SELECT * FROM tblcountry WHERE continent = 'AS' or continent = 'EU';
SELECT * FROM tblcountry WHERE continent in ('AS', 'EU');

SELECT * FROM tbldiary WHERE weather = '맑음';
SELECT * FROM tbldiary WHERE weather = '맑음' or weather = '흐림';
SELECT * FROM tbldiary WHERE weather in ('맑음', '흐림', '비');
SELECT * FROM tbldiary WHERE weather in ('맑음', '흐림') and regdate between '2019-01-20' and '2019-01-26';

SELECT * FROM tblinsa WHERE basicpay between 2000000 and 2500000;
SELECT name, basicpay, sudang FROM tblinsa;
SELECT name, basicpay, sudang FROM tblinsa WHERE basicpay + sudang between 2000000 and 2500000;

SELECT * FROM tblinsa 
WHERE jikwi in ('부장', '과장')and city in ('서울','인천');

/*

like
- WHERE 절에서 사용(조건으로 사용)
- 패턴 비교(특정한 패턴을 가지는 문자열 검색)
- 문자형을 대상으로 동작(숫자, 날짜 적용 못함)
- 정규 표현식의 간단한 버전
- 컬럼명 like '패턴 문자열'

패턴 문자열 구성 요소
1. _ : 임의의 문자 1개
2. % : 임의의 문자 0개~무한대

*/

SELECT name FROM tblinsa;
SELECT name FROM tblinsa WHERE name like '김__';
SELECT name, tel FROM tblinsa WHERE tel like '011-9___-___5';
SELECT name FROM tblinsa WHERE name like '_길_';

SELECT * FROM employees WHERE first_name like 'A________'; -- 정밀도 높음, 검색률 낮음
SELECT * FROM employees WHERE first_name like 'A%'; -- 정밀도 낮음, 검색률 높음
SELECT * FROM employees WHERE first_name like '%a';
SELECT * FROM employees WHERE first_name like 'A%a';
SELECT * FROM employees WHERE first_name like 'A%a%a';
SELECT * FROM employees WHERE first_name like '%a%'; --현재 사이트 검색

/*

null
- 자바의 null과 유사
- 직접 표현도 가능(null)
- 컬럼이 비어있는 상태(셀)

null은 연산의 대상이 될 수 없다.(모든 언어 공통)

null 조건
- WHERE절 사용
- 컬럼명 is null

*/

-- 인구수가 미기재된 나라?
SELECT * FROM tblcountry WHERE population is null;
SELECT * FROM tblcountry WHERE not population is null;
SELECT * FROM tblcountry WHERE population is not null;

-- tel 기재안된 사람
SELECT * FROM tblinsa WHERE tel is null;

-- 도서관.대여 테이블

-- 아직 책을 빌려간뒤 반납안한 사람??
SELECT 이름, 대여날짜, 반납날짜 FROM 대여테이블 WHERE 반납날짜 is null;

-- 마음만 먹고 아직 안한일?
SELECT * FROM tbltodo WHERE completedate is null;

-- 마음 먹고 한일?
SELECT * FROM tbltodo WHERE completedate is not null;

