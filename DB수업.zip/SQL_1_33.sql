-- 1.
SELECT * FROM tblCountry;

-- 2.
SELECT name, capital
FROM tblCountry;

--3.
SELECT name, capital, population, area, continent
FROM tblCountry;

--4.
SELECT '국가명:' || name || ', 수도명:' || capital || ', 인구수:' || population "[국가정보]"
FROM tblCountry;

--5.
SELECT first_name || last_name "[이름]" , email || '@GMAIL.COM' "[이메일]", phone_number "[연락처]", salary "[급여]"
FROM employees;

--6.
SELECT name, area
FROM tblCountry
WHERE area <= 100;

--7.
SELECT name
FROM tblCountry
Where continent in ('EU', 'AS');

-- 8.
SELECT first_name || last_name as fullname, phone_number
FROM employees
WHERE job_id = 'IT_PROG';

--9.
SELECT first_name "[이름]", phone_number "[연락처]", hire_date "[고용날짜]"
FROM employees
WHERE last_name = 'Grant';

--10.
SELECT first_name || last_name "[이름]", salary "[급여]", phone_number "[연락처]"
FROM employees
WHERE manager_id = 120;

--11.
SELECT first_name || last_name "[이름]", phone_number "[연락처]", email "[이메일]", department_id "[부서ID]"
FROM employees
WHERE department_id in ('60', '80', '100');

--12.
SELECT *
FROM tblinsa
WHERE buseo = '기획부';

--13.
SELECT name, jikwi, tel
FROM tblinsa
WHERE jikwi = '부장';

--14.
SELECT *
FROM tblinsa
WHERE basicpay + sudang >= 1500000 and city = '서울';

--15.
SELECT *
FROM tblinsa
WHERE sudang <= 150000 and jikwi in ('사원','대리');

--16.
SELECT *
FROM tblinsa
WHERE basicpay*12 >= 20000000 and jikwi in ('과장', '부장');

--17.
SELECT *
FROM tblCountry
WHERE name like '%국';

--18.
SELECT *
FROM employees
WHERE phone_number like '515%';

--19.
SELECT *
FROM employees
WHERE job_id like 'SA%';

--20.
SELECT *
FROM employees
WHERE first_name like '%de%' or first_name like '%DE%' or first_name like '%De%' or first_name like '%dE%';

--21.
SELECT *
FROM tblinsa
WHERE ssn like '______-1%';

--22.
SELECT *
FROM tblinsa
WHERE ssn like '______-2%';

--23.
SELECT *
FROM tblinsa
WHERE ssn like '___7%' or ssn like '___8%' or ssn like '___9%';

--24.
SELECT *
FROM tblinsa
WHERE city in ('서울', '인천') and name like '김%';

--25.
SELECT *
FROM tblinsa
WHERE buseo in ('영업부', '총무부', '개발부') and jikwi in ('사원', '대리') and tel like '010%';

--26.
SELECT *
FROM tblinsa
WHERE city in ('서울', '인천', '경기') and ibsadate like '08%' or
city in ('서울', '인천', '경기') and ibsadate like '09%' or
city in ('서울', '인천', '경기') and ibsadate like '10%';

--27.
SELECT *
FROM employees
WHERE department_id is null;

--28.
SELECT distinct job_id
FROM employees;

--29.
SELECT department_id
FROM employees
WHERE hire_date between '2002-01-01' and '2004-12-31';

--30.
SELECT distinct manager_id
FROM employees
WHERE salary >= 5000;

--31.
SELECT distinct jikwi 
FROM tblinsa
WHERE ssn like '%-1%' and ssn like '8%';

--32.
SELECT distinct city
FROM tblinsa
WHERE sudang > 200000;

--33.
SELECT distinct buseo
FROM tblinsa
WHERE tel is null;

