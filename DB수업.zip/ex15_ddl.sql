-- ex15_ddl

/*

DML
- SELECT 문

DDL
- 데이터 정의어
- 객체를 생성, 수정, 삭제한다.
- 객체 : 테이블, 뷰, 인덱스, 트리거, 프로시저, 제약사항 등..
- CREATE, ALTER, DROP

테이블 생성하기 -> 컬럼 구성하는 작업

CREATE TABLE 테이블명
(
    컬럼 정의,
    컬럼 정의,
    컬럼 정의,
    컬럼명 자료형(길이) NULL표기 제약사항
);

*/

CREATE TABLE tblType
(
    num number(3)
);

/*

컬럼명 자료형(길이) NULL표기 제약사항

제약 사항 Constraint
- 해당 컬럼에 들어갈 데이터(값)에 대한 조건(규제) -> 조건을 만족하지 못하면 데이터를 해당 컬럼에 넣지 못한다. > 유효성 검사
- 데이터베이스 무결성 보장(Integrity Contraint Rule - 무결성 제약 조건)

1. NOT NULL
- 반드시 값을 가져야 한다.(필수값)

*/

CREATE TABLE tblMemo
(
    seq number not null, -- 메모 번호 + 필수값(Required)
    name varchar2(20) null, -- 작성자 + 선택값(Optional)
    memo varchar2(2000) not null, -- 메모내용 + 필수값
    regdate date null -- 작성 시각 + 선택값
);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 1, '홍길동', '메모 내용입니다', sysdate );
    
INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 2, '아무개', NULL , sysdate );
    
INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( null, '아무개', '하하하' , sysdate );

INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 3, null, '하하하' , null );

SELECT * FROM tblMeMO;

/*

2. PRIMARY KEY(PK), 기본키
- 키(컬럼)
- 가장 중요한 컬럼 -> 행과 행을 구분하는 역할(************)
- 객체(행, 레코드, 튜플) 식별자(*******)
- Unique(유일)
- UNIQUE(유일) + not null(필수값)
- 테이블에는 반드시 PK가 존재해야 한다.
- 보통 PK가 테이블에 1개 존재한다. -> 가끔씩 PK가 2개 이상 만드는 경우가 있다. -> 복합키(Composite Key)(나중에 알려줌)

*/

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
     seq number primary key, --primary key 안에 not null이 포함되어있음
    name varchar2(20) null,
    memo varchar2(2000) not null,
    regdate date null
);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 1, '홍길동', '메모 내용입니다', sysdate );

/*

3. UNIQUE
- 해당 컬럼값 테이블에 동일한 값이 존재할 수 없게 만드는 역할
- 유일한 값 보장
- PK와 유사. NULL을 가질 수 있다.
- UNIQUE + NOT NULL = PRIMARY KEY
- UNIQUE가 걸린 컬럼을 식별자로 사용하지 말것!!(NULL이 있어서)
- NULL은 여러개 사용 가능

*/

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
     seq number primary key, --primary key 안에 not null이 포함되어있음
    name varchar2(20) UNIQUE,
    memo varchar2(2000) not null,
    regdate date null
);
INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 1, '홍길동', '메모 내용입니다', sysdate );

INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 2, '홍길동', '메모 내용입니다', sysdate ); -- 안됨 UNIQUE 오류

INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 2, '아무개', '메모 내용입니다', sysdate );
    
INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 3, NULL, '메모 내용입니다', sysdate );
        
INSERT INTO tblMemo (seq, name, memo, regdate)
    values ( 4, NULL, '메모 내용입니다', sysdate );
SELECT * FROM tblMemo;

/*

4. CHECK
- 열거, 범위 비교를 통한 제약(사용자 정의형)
- WHERE절 만드는 것과 유사(WHERE 절에서 사용가능한 구문들을 사용할 수 있다.)
- 데이터가 들어가기전에 애초에 싹을 잘라야함

*/

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
     seq number primary key, --primary key 안에 not null이 포함되어있음
    --name varchar2(20) CHECK (name = '홍길동' or name = '아무개' or name = '테스트'), -- 회원제 운영(홍길동, 아무개, 테스트)
    name varchar2(20) CHECK (name in ('홍길동', '아무개', '테스트')),
    memo varchar2(2000) not null,
    regdate date null,
    length number check(length between 20 and 100)-- 범위(20 ~ 100)
);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values('1', '홍길동', '하하하', sysdate);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values('1', '호호', '하하하', sysdate); -- name컬럼의 check 제약에 위배됨
    
INSERT INTO tblMemo (seq, name, memo, regdate, length)
    values('1', '홍길동', '하하하', sysdate, 50);

INSERT INTO tblMemo (seq, name, memo, regdate, length)
    values('2', '홍길동', '하하하', sysdate, 200); -- length컬럼의 check 제약에 위배됨

SELECT * FROM tblMemo;

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
     seq number primary key, --primary key 안에 not null이 포함되어있음
    --name varchar2(20) CHECK (name = '홍길동' or name = '아무개' or name = '테스트'), -- 회원제 운영(홍길동, 아무개, 테스트)
    name varchar2(20) CHECK (name in ('홍길동', '아무개', '테스트')),
    memo varchar2(2000) not null,
    regdate date CHECK (not to_char(regdate, 'd') in (1,7) ), -- 토,일 작성금지!!
    length number check(length between 20 and 100)-- 범위(20 ~ 100)
);

INSERT INTO tblMemo (seq, name, memo, regdate, length)
    values('2', '홍길동', '하하하', sysdate, 200);
    
/*

5. default
- 컬럼 기본값 지정
- 사용자가 컬럼값을 대입하지 않으면 미리 준비해 둔 기본값을 대신 대입
- 암시적으로 사용하지 않아야 default 적용됨

*/

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
     seq number primary key,
     name varchar2(20) default '익명' null,
    memo varchar2(2000) not null,
    regdate date default sysdate
);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values('2', '홍길동', '하하하', sysdate);

INSERT INTO tblMemo (seq, memo)
    values('1', '하하하');

SELECT * FROM tblMemo;

/*
제약 사항을 만드는 방법

1. 컬럼 수준에서 만드는 방법(이때까지 수업했던 방식)
    - 컬럼 1개를 정의할 때 제약을 같이 정의하는 방식
    - seq number primary key
    - 컬럼명 자료형(길이) [constraint 제약명] 제약조건
    
2. 테이블 수준에서 만드는 방법( 1,2 번을 나누는 이유 : 가독성 때문, 2번이 가독성이 좋고 코드가 깔끔함 )
    - 컬럼 정의할 때 제약을 정의하지 않고, 나중에 추가로 정의하는 방식
    - seq number
    - primary key
    - constraint 제약명 제약조건
    
*/

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
--     seq number primary key, -- 컬럼 수준 정의(생략 버전)
--     seq number constraint aaa primary key, -- 컬럼 수준 정의(원본) aaa : 제약 사항명
--     seq number constraint tblMemo_seq_pk primary key, -- 권장 표현(***)
    seq number,
     name varchar2(20),
    memo varchar2(2000),
    regdate date,
    
    constraint tblMemo_seq_pk primary key(seq), -- 테이블 수준의 제약 정의
    constraint tblMemo_name_ck CHECK(name in ('홍길동', '아무개') ),
    constraint tblMemo_regdate_ck CHECK(to_char(regdate, 'mm') = '03')
);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values('1', '홍길동', '하하하', sysdate);

-- ORA-00001: unique constraint (HR.SYS_C007053) violated
-- ORA-00001: unique constraint (HR.AAA) violated
INSERT INTO tblMemo (seq, name, memo, regdate)
    values('2', '홍길동', '하하하', sysdate);

UPDATE tblMemo set name = '아무개' WHERE seq = 1;
UPDATE tblMemo set name = '유재석' WHERE seq = 1;

SELECT * FROM tblMemo;