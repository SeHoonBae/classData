/*

-- 서브쿼리 + 조인

01. tblInsa. 90년대생 남자 직원들의 평균 월급(basicpay)보다 더 많이 받는 80년대생 
    여직원들을 가져오시오.
02. tblStaff, tblProject. 현재 재직중인 모든 직원의 이름, 주소, 월급, 담당 프로젝트명을 가져오시오.
03. tblVideo, tblRent, tblMember. '뽀뽀할까요'라는 비디오를 빌려간 회원의 이름은?
04. tblInsa. 평균 이상의 월급을 받는 직원들을 가져오시오.
05. tblStaff, tblProject. '노조 협상' 프로젝트를 담당한 직원의 월급은?
06. tblMember. 가장 나이가 많은 회원의 주소?(byear)
07. tblVideo, tblRent, tblMember. '털미네이터'를 빌려갔던 회원들의 이름은?
08. tblStaff, tblProject. '서울시'에 사는 직원을 제외한 나머지 직원들의
    이름, 월급, 담당 프로젝트명을 가져오시오.
09. tblCustomer, tblSales. 상품을 2개(qty) 이상 구매한 회원의 연락처, 이름
    , 구매상품명, 수량을 가져오시오.
10. tblVideo, tblGenre. 모든 비디오의 제목과 보유수량, 대여 가격을 가져오시오.
11. tblGenre, tblVideo, tblRent, tblMember. 2007년 2월에 대여된 구매내역을 가져오시오.
    회원명, 비디오명, 언제, 대여가격
12. tblGenre, tblVideo, tblRent, tblMember. 현재 반납을 안한 회원명과 비디오명, 대여날짜를 가져오시오.

*/

--1. tblInsa. 90년대생 남자 직원들의 평균 월급(basicpay)보다 더 많이 받는 80년대생 여직원들을 가져오시오.
SELECT * 
    FROM tblInsa 
        WHERE substr(ssn,1,1) = 8 and substr(ssn,8,1) = 2 and basicpay > (SELECT avg(basicpay) FROM tblInsa WHERE substr(ssn,1,1) = 9 and substr(ssn,8,1) = 1);

--2. tblStaff, tblProject. 현재 재직중인 모든 직원의 이름, 주소, 월급, 담당 프로젝트명을 가져오시오.
SELECT * FROM tblStaff;
SELECT * FROM tblProject;
SELECT s.name, s.address, s.salary, p.projectname 
    FROM tblStaff s
        LEFT OUTER JOIN tblProject p
            ON s.seq = p.staffseq
                ORDER BY s.name;

--3. tblVideo, tblRent, tblMember. '뽀뽀할까요'라는 비디오를 빌려간 회원의 이름은?
SELECT * FROM tblMember;
SELECT * FROM tblRent;
SELECT * FROM tblVideo;
SELECT m.name 
    FROM tblMember m
        INNER JOIN tblRent r
            ON m.seq = r.member
                INNER JOIN tblVideo v
                    ON r.video = v.seq
                        WHERE v.name = '뽀뽀할까요';

--4. tblInsa. 평균 이상의 월급을 받는 직원들을 가져오시오.
SELECT * FROM tblInsa;
SELECT * FROM tblInsa
    WHERE basicpay >= (SELECT round(avg(basicpay)) FROM tblInsa );

--5. tblStaff, tblProject. '노조 협상' 프로젝트를 담당한 직원의 월급은?
SELECT * FROM tblStaff;
SELECT * FROM tblProject;
SELECT s.salary
    FROM tblStaff s
        INNER JOIN tblProject p
            ON s.seq = p.staffseq
                WHERE p.projectname = '노조 협상';
                
--6. tblMember. 가장 나이가 많은 회원의 주소?(byear)
SELECT * FROM tblMember;
SELECT address 
    FROM tblMember
        WHERE byear = (SELECT min(byear) FROM tblMember);

--7.tblVideo, tblRent, tblMember. '털미네이터'를 빌려갔던 회원들의 이름은?
SELECT * FROM tblVideo;
SELECT * FROM tblRent;
SELECT * FROM tblMember;
SELECT m.name 
    FROM tblMember m
        INNER JOIN tblRent r
            ON M.seq = r.member
                INNER JOIN tblVideo v
                    ON r.video = v.seq
                        WHERE v.name = '털미네이터';
                        
--8. tblStaff, tblProject. '서울시'에 사는 직원을 제외한 나머지 직원들의 이름, 월급, 담당 프로젝트명을 가져오시오.
SELECT * FROM tblStaff;
SELECT * FROM tblProject;
SELECT s.name, s.salary, p.projectname
    FROM tblStaff s
        LEFT OUTER JOIN tblProject p
            ON s.seq = p.staffseq
                WHERE s.address <> '서울시';
                
--9. tblCustomer, tblSales. 상품을 2개(qty) 이상 구매한 회원의 연락처, 이름, 구매상품명, 수량을 가져오시오.
SELECT * FROM tblCustomer;
SELECT * FROM tblSales;
SELECT c.tel, c.name, s.item, s.qty
    FROM tblCustomer c
        INNER JOIN tblSales s
            ON c.seq = s.customerseq
                WHERE s.qty >= 2;
                
--10. tblVideo, tblGenre. 모든 비디오의 제목과 보유수량, 대여 가격을 가져오시오.
SELECT * FROM tblVideo;
SELECT * FROM tblGenre;
SELECT * FROM tblRent;
SELECT v.name, v.qty, g.price
    FROM tblGenre g
        RIGHT OUTER JOIN tblVideo v
            ON g.seq = v.genre;
            
--11. tblGenre, tblVideo, tblRent, tblMember. 2007년 2월에 대여된 구매내역을 가져오시오. 회원명, 비디오명, 언제, 대여가격
SELECT * FROM tblRent;
SELECT * FROM tblMember;
SELECT * FROM tblVideo;
SELECT * FROM tblGenre;
SELECT m.name, v.name, r.rentdate, g.price
    FROM tblGenre g
        INNER JOIN tblVideo v
            ON g.seq = v.genre 
                INNER JOIN tblRent r
                    ON v.seq = r.video
                        INNER JOIN tblMember m
                            ON r.member = m.seq
                                WHERE to_char(r.rentdate, 'yyyy-mm') = '2007-02';
                                
--12. tblGenre, tblVideo, tblRent, tblMember. 현재 반납을 안한 회원명과 비디오명, 대여날짜를 가져오시오.
SELECT * FROM tblRent;
SELECT * FROM tblMember;
SELECT * FROM tblVideo;
SELECT * FROM tblGenre;
SELECT m.name, v.name, r.rentdate
    FROM tblMember m
        INNER JOIN tblRent r
            ON m.seq = r.member
                INNER JOIN tblVideo v
                    ON v.seq = r.video
                        WHERE r.retdate is null;



