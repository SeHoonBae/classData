-- ex10_function

/*

오라클(SQL)
- 수많은 기능 제공 -> 함수 형태로 제공

집계 함수(통계)
1. count() : 개수
2. sum() : 합
3. avg() : 평균
4. max() : 최댓값
5. min() : 최솟값

1. count()
- 결과셋의 레코드 개수를 반환(null은 제외) ***
- 매개변수는 1개만 허용(2개 이상의 컬럼은 넣을 수 없다.) > 예외 : * 가능
- number count(컬럼명)

*/

SELECT name FROM tblcountry;
SELECT count(name) FROM tblcountry; -- 레코드 개수

SELECT population FROM tblcountry;
SELECT count(population) FROM tblcountry;
SELECT population FROM tblcountry;

SELECT name, population FROM tblcountry;
SELECT count(name), count(population) FROM tblcountry;
SELECT count(*) FROM tblcountry;

-- 모든 직원이 몇명? //무조건
SELECT count(*) FROM tblinsa;

-- 연락처가 있는 직원이 몇명?
SELECT count(tel)
FROM tblinsa;

SELECT count(tel)
FROM tblinsa
WHERE tel is null; --null을 못세기 때문에 0이 나옴

SELECT count(name), count(buseo), count(tel) FROM tblinsa;

SELECT
    count(*) as "[총인원수]",
    count(*)-count(tel) as "연락처 미기재 인원",
    count(tel) as "연락처 기재 인원수"
FROM tblinsa;

SELECT 
    count(name),
    count(100), -- count(*)과 같음
    '하하하'
FROM tblinsa;

-- 당신 회사에는 어떤 부서들이 있습니까?
SELECT distinct buseo FROM tblinsa;

-- 당신 회사에는 부서가 몇개 있습니까?
SELECT count(distinct buseo) FROM tblinsa;

-- 개그맨 남자 몇명?
SELECT * FROM tblcomedian;
SELECT count(*) FROM tblcomedian WHERE gender = 'm';
SELECT count(*) FROM tblcomedian WHERE gender = 'f';

-- 한번에 보고 싶다.(남자 8 여자 2) (*****)
SELECT 
    count(case
        when gender = 'm' then '남자'
        when gender = 'f' then '여자'
    end),
    count(case
        when gender = 'm' then '남자'
    end),
    count(case
        when gender = 'f' then '여자'
    end)
FROM tblcomedian;

-- count(*) : 테이블의 전체 레코드 수
-- 등록된 할일이 몇건? -> 20건
-- 의도 파악
SELECT count(*) FROM tbltodo;

-- 할일을 마친 건수?
SELECT count(completedate) FROM tbltodo;

-- 아직 하지 않은 건수? -> 8건
SELECT count(*)- count(completedate) FROM tbltodo;
SELECT count(*) FROM tbltodo WHERE completedate is null;

-- 남자 직원수
SELECT count(*) FROM tblinsa WHERE ssn like '%-1%';

-- 남자 몇명? + 남자 직원들 이름?
-- 집계함수와 단일컬럼은 동시에 사용이 불가능하다. -> 
SELECT count(*), name FROM tblinsa WHERE ssn like '%-1';

SELECT avg(basicpay) FROM tblinsa;
--직원 중 평균 급여보다 더 많은 급여를 받는 직원?
SELECT * FROM tblinsa WHERE basicpay > 1550000;
--ORA-00934: group function is not allowed here
--WHERE 절은 개인(한 행, 레코드 1개, 객체)에 대한 질문을 하는 곳이다.
SELECT * FROM tblinsa WHERE basicpay > avg(basicpay);

-- tblinsa 급여 -> 100만원대별로 직원수?
SELECT 
    count(case
        when basicpay < 1000000 then 1
        end),
    count(case
        when basicpay between 1000000 and 2000000 then 1
        end),
    count(case
        when basicpay >= 2000000 then 1
        end)
FROM tblinsa;

/*
tblCountry
1. 아시아(AS)와 유럽(EU)에 속한 국가는 총 몇개? - in, count
2. 인구수가 7000~20000 사이인 국가는 총 몇개? - between, count
employees
3. IT_PROG 중에서 급여가 5000불이 넘는 직원 몇명? - count
tblinsa
4. 010을 안쓰는 사람은 몇명?(연락처가 없는 사람은 제외)
5. 서울 사람 빼고 나머지 몇명?
6. 80년대생 + 여자직원 몇명?
*/
--1.
SELECT count(*)
FROM tblCountry
WHERE continent in ('AS', 'EU');
--2.
SELECT count(*)
FROM tblCountry
WHERE population between 7000 and 20000;
--3.
SELECT count(*)
FROM employees
WHERE job_id = 'IT_PROG' and salary >5000;
--4.
SELECT count(*)
FROM tblinsa
WHERE tel not like '010%';
--5.
SELECT count(*)
FROM tblinsa
WHERE city <> '서울';

--6.
SELECT count(*)
FROM tblinsa
WHERE ssn like '8%' and ssn like '%-2%';

/*
    2. sum()
    - number sum(컬럼명)
    - 해당 컬럼값들의 합을 구한다
    - 숫자 컬럼을 대상으로 한다.

*/

SELECT sum(weight) FROM tblcomedian;
SELECT sum(first) FROM tblcomedian;

SELECT sum(weight + 10) FROM tblcomedian;

SELECT sum(population) FROM tblcountry; -- null은 제외

-- 이번 달 총 급여 지급액? + 총 수당
SELECT sum(basicpay), sum(sudang), sum(basicpay) + sum(sudang), sum(basicpay + sudang) FROM tblinsa;

-- 한달 평균 급여?
SELECT sum(basicpay) / count(basicpay)
FROM tblinsa;

/*
3. avg()
- number avg(컬럼명)
- 컬럼값들의 평균값을 반환한다.
- 숫자 컬럼을 대상으로 한다.
*/

-- 나라별 평균 인구수
SELECT avg(population) FROM tblcountry; --18215

SELECT sum(population) / count(*) FROM tblcountry; -- 16914
SELECT sum(population) / count(population) FROM tblcountry; -- 18215

-- 회사 보너스 지급
-- 실적에 따라서 지급
-- 일부 직원은 실적이 없다.
--1. 실적이 있는 사람들에 한해서 지급 > count(실적) = avg()
--2. 모든 사람에 대해서 지급 > count(*)


/*
4. max()
5. min()
- object max(컬럼명) > 최댓값 반환
- object min(컬럼명) > 최솟값 반환
- 숫자, 날짜, 문자 모두 적용
*/

SELECT max(basicpay) FROM tblinsa;

SELECT min(ibsadate) FROM tblinsa; -- 2005-02-23, 최고참의 입사일
SELECT max(ibsadate) FROM tblinsa; -- 2015-09-26, 신입 입사일

SELECT max(name) FROM tblinsa; -- 황진이

SELECT name, buseo, jikwi FROM tblinsa order by buseo asc,name asc,jikwi asc;

SELECT
    count(*) as "총직원수",
    sum(basicpay) as "총급여액",
    avg(basicpay) as "평균급여",
    max(basicpay) as "최대급여",
    min(basicpay) as "최소급여"
FROM tblinsa;

SELECT 
    case
    when max(basicpay) then '최대급여'
    end
FROM tblinsa;

/*
sum()
1. 유렵과 아프리카에 속한 나라의 인구 수 합? tblCountry
2. 매니저(108)이 관리하고 있는 직원들의 급여 합? employees
3. 직업(ST_CLERK, SH_CLERK)을 가지는 직원들의 급여 합? employees
4. 서울에 있는 직원ㄷ르의 급여 합(급여 + 수당)? tblinsa
5. 장급(부장+과장)들의 총급여합? tblinsa

avg()
1. 아시아에 속한 국가의 평균 인구수? tblCountry
2. 이름(first_name)에 'AN'이 포함된 직원들의 평균 급여?(대소문자 구분안함) employees
3. 장급(부장,과장)의 평균 급여? tblinsa
4. 사원급(대리,사원)의 평균 급여? tblinsa
5. 장급(부장,과장)의 평균 급여와 사원급(대리,사원)의 평균 급여의 차이는 얼마? tblinsa

max(), min()
1. 면적이 가장 넓은 나라의 면적? tblCountry
2. 급여(급여+수당)가 가장 적은 직원은 얼마 받는가? tblinsa
*/
/*
sum()
1. 유렵과 아프리카에 속한 나라의 인구 수 합? tblCountry
2. 매니저(108)이 관리하고 있는 직원들의 급여 합? employees
3. 직업(ST_CLERK, SH_CLERK)을 가지는 직원들의 급여 합? employees
4. 서울에 있는 직원들의 급여 합(급여 + 수당)? tblinsa
5. 장급(부장+과장)들의 총급여합? tblinsa
*/
-- sum()
--1.
SELECT sum(population) FROM tblCountry WHERE continent in ('EU', 'AF');
--2.
SELECT sum(employees.salary) FROM employees WHERE manager_id = 108;
--3.
SELECT sum(employees.salary) FROM employees WHERE job_id in ('ST_CLERK' , 'SH_CLERK');
--4.
SELECT sum(tblinsa.basicpay + sudang) FROM tblinsa WHERE city = '서울';
--5.
SELECT sum(tblinsa.basicpay) FROM tblinsa WHERE jikwi in ('부장', '과장');
/*
avg()
1. 아시아에 속한 국가의 평균 인구수? tblCountry
2. 이름(first_name)에 'AN'이 포함된 직원들의 평균 급여?(대소문자 구분안함) employees
3. 장급(부장,과장)의 평균 급여? tblinsa
4. 사원급(대리,사원)의 평균 급여? tblinsa
5. 장급(부장,과장)의 평균 급여와 사원급(대리,사원)의 평균 급여의 차이는 얼마? tblinsa
*/
-- avg()
--1.
SELECT avg(population) FROM tblCountry WHERE continent = 'AS';
--2.
SELECT avg(employees.salary) FROM employees WHERE first_name like '%an%' or first_name like '%AN%' or first_name like '%An%' or first_name like '%aN%';
SELECT AVG(salary) FROM employees WHERE upper(first_name) like '%AN%';
--3.
SELECT trunc(avg(tblinsa.basicpay)) FROM tblinsa WHERE jikwi in ('부장','과장');
--4.
SELECT round(avg(tblinsa.basicpay)) FROM tblinsa WHERE jikwi in ('대리','사원');
--5.
SELECT 
    avg(case
            when jikwi in ('부장' , '과장') then basicpay
        end) -
    avg(case
        when jikwi = '대리' or jikwi = '사원' then basicpay
    end)
FROM tblinsa;

/*
max(), min()
1. 면적이 가장 넓은 나라의 면적? tblCountry
2. 급여(급여+수당)가 가장 적은 직원은 얼마 받는가? tblinsa
*/
--1.
SELECT max(area) FROM tblCountry;
--2.
SELECT min(basicpay + sudang) FROM tblinsa;


