-- ex16_sequence

/*

시퀀스, sequence
- DB Object 중 하나
- 식별자를 만드는데 주로 사용한다.(PK에 적용)
- 중복되지 않고 순차적으로 증가하는 숫자를 반환한다.

시퀀스 객체 조작하기
1. CREATE : 생성
2. ALTER : 수정
3. DROP : 삭제

시퀀스 객체 생성하기
- CREATE SEQUENCE 시퀀스명;

시퀀스 객체 사용방법
1. testSeq.nextVal // 사용
2. testSeq.currVal

*/

CREATE SEQUENCE testSeq;

SELECT testSeq.nextVal FROM dual; -- 값을 사용하는데 쓰임 > stack.pop()와 비슷
SELECT testSeq.currVal FROM dual; -- 값을 단순하게 확인하는데 쓰임 > stack.peek()와 비슷 > 현재 로그인에서 한번이라도 nextVal을 실행해야 확인 가능하기 때문에 사용도가 많이 떨어짐

DROP TABLE tblMemo;

CREATE TABLE tblMemo
(
     seq number primary key,
     name varchar2(20),
    memo varchar2(2000),
    regdate date
);

INSERT INTO tblMemo (seq, name, memo, regdate)
    values(testSeq.nextVal, '홍길동', '하하하', sysdate);
    
SELECT * FROM tblMemo; --27

-- 테이블 식별자(PK)
-- 1. 숫자
-- 2. 문자열
--  ex) 상품 테이블
--      1   마우스 3000
--      2   키보드 5000
--  ex) 상품 테이블
--      A001    마우스 3000
--      B002    키보드 5000

CREATE SEQUENCE productSeq;

-- 상품 등록 과정 > 대(AA) + 중(VB) + 소(OP) 선택 과정 > 'AAVBOP001'
SELECT 'AAVBOP' || ltrim(to_char(productSeq.nextVal, '000')) FROM dual;

---------------------------------------------------------------- 끝

-- 시퀀스 내부 + 옵션
-- CREATE SEQUENCE testSeq; -- 기본형(가장 많이 사용)
-- CREATE SEQUENCE testSeq 옵션 옵션 옵션 옵션...;
DROP SEQUENCE testSeq;
CREATE SEQUENCE testSeq; -- 다시 1부터 시작

CREATE SEQUENCE testSeq 
    increment by 1 -- 증감치 조절, 음수는 -1부터 시작 양수는 1부터 시작
    start with 20 -- 시작값(seed)
    maxvalue 10 --최댓값(넘으면 에러 발생)
    minvalue 1; -- 최솟값

CREATE SEQUENCE testSeq
    increment by 1
    start with 1
    maxvalue 15
    cycle -- 순환
    cache 14;
    
CREATE SEQUENCE testSeq cache 50; // cache 건들이지 말것
    
    
SELECT testSeq.nextVal FROM dual;






