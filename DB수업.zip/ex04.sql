/*
SELECT 문
-DML, DQL
- SQL(Q - SELECT)
- 가장 빈도수가 높다.(연습 가장 많이 할 것)
- 사용 목적 : 데이터베이스로부터 원하는 데이터를 가져오는 명령어(읽기)
- 기본 구문
    - SELECT 컬럼리스트 FROM 테이블명;
        - SELECT 컬럼리스트 //SELECT 절 : 가져올 컬럼을 지정한다.
        - FROM 테이블명 //FROM 절(구) : 가져올 테이블 지정한다.
    - 절마다 실행순서가 있다.
        - FROM(1) > SELECT(2)
        
    -결과 테이블(Result TABLE, Result Set) -> 복사본
        
        
*/


SELECT name --2.
FROM tblCountry; --1.

-- 1. 컬럼명
-- 2. 테이블명.컬럼명
-- 3. 계정명(스키마).테이블명.컬럼명
SELECT hr.tblCountry.name
FROM hr.tblCountry;


-- 데이터 보기
SELECT * FROM tblCountry;

-- 클라이언트 툴 사용
-- 현재 소유주가 소유하고 있는 테이블 명단
SELECT * FROM tabs; --tables(시스템 테이블)

-- tblCountry > 컬럼 구성 > 1. DDL 2. desc
desc tblCountry; --컬럼명. 자료형. 널(필수입력) -- SQL*Plus 명령어. 다른 툴 실행 불가

-- 단일 컬럼
SELECT name FROM tblCountry;

-- 다중 컬럼
SELECT name, capital FROM tblCountry;
SELECT name, capital, population, continent, area FROM tblCountry;
SELECT * FROM tblCountry; -- *, wild card //모든 컬럼

-- 원본의 컬럼순서와 다르게 명시
SELECT name, capital, area, continent, population FROM tblCountry;

SELECT name, name, name FROM tblCountry;

