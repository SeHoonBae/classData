-- ex25_pseudo

/*

의사 컬럼, Pseudo Column
- 실제 컬럼이 아닌데 컬럼처럼 행동하는 객체
- 오라클 전용
- rownum, MS-SQL(top), MYSQL(limit)

*/

SELECT name, buseo, jikwi, rownum FROM tblinsa;

-- 1이 포함된 것
SELECT name, buseo, jikwi, rownum FROM tblinsa where rownum = 1;
SELECT name, buseo, jikwi, rownum FROM tblinsa where rownum <= 5;
SELECT name, buseo, jikwi, rownum FROM tblinsa where rownum = 1 OR rownum = 3;

-- 1이 포함안된 것
SELECT name, buseo, jikwi, rownum FROM tblinsa where rownum = 5; -- *** 1번부터 순서를 찾지만 아닐경우 번호가 동적으로 변함
SELECT name, buseo, jikwi, rownum FROM tblinsa where rownum >= 3 and rownum <= 6;

-- rownum은 from절이 실행 시 매겨진다.
SELECT name, buseo, jikwi, basicpay , rownum FROM tblinsa order by basicpay;

SELECT a.*, rownum
FROM (SELECT name, buseo, jikwi, basicpay, rownum from tblinsa order by basicpay desc) a
    WHERE rownum <= 5;

SELECT a.*, rownum 
    FROM(SELECT * FROM tblinsa ORDER BY sudang DESC) a
        WHERE rownum >= 5 and rownum <= 10;

-- rownum을 조건으로 마음대로 사용하려면 최소한 서브쿼리가 3번 중첩이 되어야 한다.
-- rownum 을 고정시킨다.
SELECT b.*, rownum 
    FROM(SELECT a.*, rownum AS rnum 
        FROM (SELECT * FROM tblinsa ORDER BY sudang DESC) a)b
            WHERE rnum >= 1 and rnum <= 10; -- 1페이지

SELECT b.*, rownum FROM
    (SELECT a.*, rownum AS rnum 
        FROM (SELECT * FROM tblinsa ORDER BY sudang DESC) a)b
            WHERE rnum >= 11 and rnum <= 20; -- 2페이지

-- tblcountry 인구수가 가장 많은 나라 1~3위까지
SELECT b.*, rownum 
    FROM (SELECT a.*, rownum AS rnum
    FROM(SELECT * FROM tblcountry WHERE population is not null ORDER BY population DESC)a) b
        WHERE rnum <= 3;

--tblinsa. 남자 + 부서별 인원이 가장 많은 3부서
SELECT * FROM
    (SELECT a.*, rownum as rnum FROM
        (SELECT buseo, count(*) FROM tblinsa
            WHERE substr(ssn, 8, 1) = '1'
                GROUP BY buseo
                    ORDER BY COUNT(*) desc) a)
                        where rnum <= 3;







