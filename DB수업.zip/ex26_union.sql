-- ex26_union

/*

JOIN, 조인
- 테이블을 합치는 기술
- 횡, 가로, 컬럼끼리 병합
- 분산되어 있는 정보(컬럼)를 하나의 결과셋에서 보고 싶을 때 사용

UNION, 유니온
- 테이블을 합치는 기술
- 종, 세로, 레코드 병합
- 합치는 테이블끼리 컬럼 갯수와 자료형, 데이터가 같아야 한다.
- 분산되어 있는 데이터(레코드, 객체, 행) 하나의 결과셋에서 보고 싶을 때 사용

*/

SELECT * FROM tblmen;
SELECT * FROM tblwomen;

-- 남,녀 모두를 보고싶습니다.
SELECT * FROM tblmen 
UNION 
SELECT * FROM tblwomen;

-- 회사, 부서별 게시판
CREATE TABLE tblUnion1 -- 영업부 게시판
(
    seq NUMBER PRIMARY KEY,
    subject VARCHAR2(100) NOT NULL
);

CREATE TABLE tblUnion2 -- 총무부 게시판
(
    seq NUMBER PRIMARY KEY,
    subject VARCHAR2(100) NOT NULL
);

CREATE TABLE tblUnion3 -- 기획부 게시판
(
    seq NUMBER PRIMARY KEY,
    subject VARCHAR2(100) NOT NULL
);

-- 게시물
INSERT INTO tblUnion1 values (1, '영업부 게시판입니다.');
INSERT INTO tblUnion1 values (2, '영업부 게시판입니다.');
INSERT INTO tblUnion1 values (3, '영업부 게시판입니다.');

INSERT INTO tblUnion2 values (1, '총무부 게시판입니다.');
INSERT INTO tblUnion2 values (2, '총무부 게시판입니다.');
INSERT INTO tblUnion2 values (3, '총무부 게시판입니다.');
INSERT INTO tblUnion2 values (4, '총무부 게시판입니다.');

INSERT INTO tblUnion3 values (1, '기획부 게시판입니다.');
INSERT INTO tblUnion3 values (2, '기획부 게시판입니다.');

SELECT * FROM tblUnion1;
SELECT * FROM tblUnion2;
SELECT * FROM tblUnion3;

-- 사장님 왈. 모든 게시물 보고싶다..
SELECT * FROM tblUnion1
UNION
SELECT * FROM tblUnion2
UNION
SELECT * FROM tblUnion3;

-- 축구 선수. 공격수, 수비수
CREATE TABLE 공격수
(
    이름 VARCHAR2(30) PRIMARY KEY, -- 일반 특성
    키 NUMBER NOT NULL, -- 일반 특성
    몸무게 NUMBER NOT NULL, -- 일반 특성
    근력 NUMBER NOT NULL, -- 공격수 특징
    스피드 NUMBER NOT NULL -- 공격수 특징
);

CREATE TABLE 수비수
(
    이름 VARCHAR2(30) PRIMARY KEY, -- 일반 특성
    키 NUMBER NOT NULL, -- 일반 특성
    몸무게 NUMBER NOT NULL, -- 일반 특성
    지구력 NUMBER NOT NULL -- 수비수 특징
);

INSERT INTO 공격수 VALUES ('홍길동', 180, 80, 100, 90);
INSERT INTO 공격수 VALUES ('아무개', 185, 82, 90, 96);

INSERT INTO 수비수 VALUES ('하하하', 190, 78, 90);
INSERT INTO 수비수 VALUES ('호호호', 189, 75, 95);

SELECT * FROM 공격수;
SELECT * FROM 수비수;

-- 컬럼 수가 달라 에러
-- ORA-01789: query block has incorrect number of result columns
SELECT * FROM 공격수
UNION
SELECT * FROM 수비수;

SELECT * FROM 공격수
UNION
SELECT a.*, rownum FROM 수비수 a;

SELECT 이름, 키, 몸무게 FROM 공격수
UNION
SELECT 이름, 키, 몸무게 FROM 수비수;

-- 컬럼 개수가 다를 때 0으로 컬럼 개수를 맞춰준다.
SELECT 이름, 키, 몸무게, 근력, 스피드, 0 FROM 공격수
UNION
SELECT 이름, 키, 몸무게, 0, 0, 지구력 FROM 수비수;


CREATE TABLE tblUnionA
(
    name VARCHAR2(20) NOT NULL
);

CREATE TABLE tblUnionB
(
    name VARCHAR2(20) NOT NULL
);

INSERT INTO tblUnionA values ('빨강');
INSERT INTO tblUnionA values ('파랑');
INSERT INTO tblUnionA values ('노랑');
INSERT INTO tblUnionA values ('검정');
INSERT INTO tblUnionA values ('하양');

INSERT INTO tblUnionB values ('주황');
INSERT INTO tblUnionB values ('초록');
INSERT INTO tblUnionB values ('빨강'); -- **
INSERT INTO tblUnionB values ('남색');
INSERT INTO tblUnionB values ('검정'); -- **

-- union
-- 두 테이블을 합쳤을 때 중복되는 행을 자동으로 제거
SELECT * FROM tblUnionA
union
SELECT * FROM tblUnionB;

-- union all
-- 두 테이블을 합쳤을 때 중복되는 행도 같이 가져오기
SELECT * FROM tblUnionA
union all
SELECT * FROM tblUnionB;

-- intersect
-- 두 테이블을 합쳤을 때 중복되는 행만 가져오기
SELECT * FROM tblUnionA
intersect
SELECT * FROM tblUnionB;

-- minus
-- 두 테이블을 합쳤을 때 첫번째 테이블에서 중복되는 행을 제외한 나머지 가져오기(차집합)
SELECT * FROM tblUnionA
minus
SELECT * FROM tblUnionB;

 






