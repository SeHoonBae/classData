-- ex11_function

/*

숫자 함수(수학 함수)
- 자바의 Math 클래스

1. round()
- 반올림 함수
- number round(컬럼명)
- number round(컬럼명, 자릿수)

*/

SELECT round(987.654) FROM dual;
SELECT round(987.654,1) FROM dual;
SELECT round(987.654,0) FROM dual;
SELECT round(987.654,-1) FROM dual;

SELECT round(avg(basicpay),2) FROM tblinsa;

/*
2. floor, trunc
- 절삭 함수
- 무조건 내림(버림) 함수 : 반올림을 할 수 있어도 버림 99.99 -> 99
- number floor(컬럼명)
- number trunc(컬럼명[,자릿수])
*/

SELECT floor(9.5789) FROM dual; -- 무조건 정수
SELECT trunc(99.5789,2) FROM dual; -- 자리수 지정가능

/*
3. ceil
- 무조건 올림
- number ceil(컬럼명)
*/
SELECT ceil(4.123) FROM dual; -- 무조건 정수

-- 게시판(페이징)
-- 1. 총 게시물 수
-- 2. 한페이지당 보여줄 게시물 수

SELECT ceil(61/20) as 총페이지 FROM dual;

/*

4. mod()
- 나머지 함수
- number mod(피제수, 제수)

*/
SELECT mod(10,3) FROM dual; -- 10 % 3

-- 100분 -> 몇시간 몇분?
-- 100 / 60 -> 몫(시)
-- 100 % 60 -> 나머지(분)
SELECT 
    trunc(100 / 60) as 시,
    trunc(mod(100,60)) as 분
FROM dual;