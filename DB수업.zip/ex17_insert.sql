-- ex17_insert

/*

insert 문
- 데이터를 테이블에 추가한다.(레코드 단위)
- insert into 테이블명 (컬럼리스트) values (값 리스트)
- insert
    into 테이블명 (컬럼리스트) -- 테이블 구조
    values (값 리스트) -- 구조에 따른 넣을 값

*/
DROP TABLE tblMemo;
CREATE TABLE tblMemo
(
    seq number primary key, -- 메모 번호(PK)
    name varchar2(30) not null, -- 작성자
    memo varchar2(1000) not null, -- 메모 내용
    regdate date default sysdate not null, -- 작성날짜
    etc varchar2(500) default '비고없음' null, -- 비고
    page number null -- 페이지 수
    
);

CREATE SEQUENCE memoSeq; -- 메모 번호용 시퀀스 객체

-- insert 패턴

--1. 표준 : 원본 테이블의 정의된 컬럼 순서대로 컬럼리스트와 값리스트를 표기하는 방법
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, '비고', 1);

--2. ORA-01841: (full) year must be between -4713 and +9999, and not be 0
-- 반드시 컬럼리스트의 순서와 값리스트의 순서는 일치해야 한다.
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', '비고', sysdate, 1);

--3. 원본 테이블의 컬럼순서와 insert 컬럼리스트의 순서는 아무 상관없다. 
-- 컬럼리스트 순서와 값리스트의 순서만 일치하면 된다.
insert into tblMemo (seq, name, memo,  etc, regdate, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', '비고', sysdate, 1);

--4. ORA-00947: not enough values : 컬럼리스트보다 값리스트가 적을 때
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, '비고');
    
    
--5. ORA-00913: too many values : 컬럼리스트가 값리스트보다 많을 때
insert into tblMemo (seq, name, memo, regdate, etc)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, '비고', 1);

--6. null 허용된 컬럼에 값 대입하기
-- null 허용됬지만 값을 넣은 경우 -> 선택 사항이기 때문에 잘 들어감
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, '비고', 1);

--6. null 허용된 컬럼에 값 대입하기
-- null을 일부러 넣고싶다. -> 비워두고 싶다.
-- a. 명시적으로 비우기 -> null 상수 대입
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, null, null);
    
-- b. 암시적으로 비우기 > null 컬럼이 default를 가지고 있다면 null이 아닌 기본값이 들어간다.
insert into tblMemo (seq, name, memo, regdate)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate);

select * from tblMemo;

--7. null이 허용된 컬럼만 생략이 가능하다. not null 컬럼은 생략할 수 없다.
insert into tblMemo (seq, name)
    values (memoSeq.nextVal, '홍길동');
    
--7. not null 컬럼이라도 default가 걸려있으면 생략이 가능하다. -> default가 대입되기 때문에
insert into tblMemo (seq, name, memo)
    values (memoSeq.nextVal, '홍길동', '메모입니다');

--7. not null 이 default 상태여도 null을 명시적으로 대입 불가능
insert into tblMemo (seq, name, memo, regdate)
    values (memoSeq.nextVal, '홍길동', '메모입니다', null);

--8. default(regdate, etc)
-- a. 사용자 값을 명시적으로 넣는 경우 -> 사용자가 넣은 값이 대입된다. (default 동작 안함)
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, '비고', 1);
-- b. 사용자 값을 넣기 싫음 > default 동작 > 컬럼 생략
insert into tblMemo (seq, name, memo, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', 1);
-- c. 사용자 값을 넣기 싫음 > default 동작 > default 키워드 사용
insert into tblMemo (seq, name, memo, regdate, etc, page)
    values (memoSeq.nextVal, '홍길동', '메모입니다', default, default, 1);

insert into tblMemo
    values (memoSeq.nextVal, '홍길동', '메모입니다', sysdate, '테스트', 1); -- 컬럼 리스트 생략가능

-- null 이나 default를 생략으로 값을 넣을 수 없고 명시적으로 넣어 줘야 됨

DROP TABLE tblMemoCopy;
insert into tblMemo
    values (memoSeq.nextVal, '홍길동', '메모입니다', '테스트', sysdate, 1); -- 테이블에 있는 컬럼리스트 순서와 값리스트의 순서가 다르면 에러남

SELECT * FROM tblMemoCopy; -- tblMemo 복사본, insert 11건 해야됨

INSERT INTO tblMemoCopy SELECT * FROM tblMemo WHERE page is not null;
INSERT INTO tblMemoCopy SELECT * FROM tblinsa; -- X

-- 직원 60명
SELECT * FROM tblinsa;

-- 장급(부장, 과장) 테이블 만들어 주세요.
CREATE TABLE tblInsa1(
        num NUMBER(5) NOT NULL CONSTRAINT tblInsa1_pk PRIMARY KEY
       ,name VARCHAR2(20) NOT NULL
       ,ssn  VARCHAR2(14) NOT NULL
       ,ibsaDate DATE     NOT NULL
       ,city  VARCHAR2(10)
       ,tel   VARCHAR2(15)
       ,buseo VARCHAR2(15) NOT NULL
       ,jikwi VARCHAR2(15) NOT NULL
       ,basicPay NUMBER(10) NOT NULL
       ,sudang NUMBER(10) NOT NULL
);

INSERT INTO tblinsa1
    SELECT * FROM tblinsa WHERE jikwi in ('부장', '과장');
    
SELECT * FROM tblinsa1;

-- 사원급(대리, 사원) 테이블 만들어 주세요.
CREATE TABLE tblinsa2
as
    SELECT * FROM tblinsa WHERE jikwi in ('대리', '사원');

-- CREATE TABLE + INSERT SELECT : 장급
-- : 테이블 별도 생성(제약 사항 생성)
-- : 업무용 O

-- CREATE TABLE SELECT : 사원급
-- : 테이블 자동 생성
-- : 컬럼의 복사 -> 제약 사항 복사가 안된다.
-- : 업무용 X -> 개발자 테스트용 O

CREATE TABLE tblMemoClone
as
    SELECT * FROM tblMemo;
    
SELECT * FROM tblMemoCopy; -- 장급 : 제약사항 O
SELECT * FROM tblMemoClone; -- 사원급 : 제약사항 X

INSERT INTO tblMemoCopy
    SELECT * FROM tblMemo;

INSERT INTO tblMemoClone
    SELECT * FROM tblMemo;
